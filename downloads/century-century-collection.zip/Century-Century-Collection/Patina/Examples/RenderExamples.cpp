#include "Texture.h"
#include <filesystem>
#include <fstream>
#include <iostream>
#include <string>
void integer(std::ofstream& stream,uint32_t value,int bytes)
{
    for (int i = 0; i < bytes; ++i) stream.put(static_cast<char>((value>>(i*8))&255));
}
int main(int argc,char** argv)
{
    const std::filesystem::path directory = argc > 1 ? argv[1] : "Examples";
    std::filesystem::create_directories(directory);
    const int rate = 44100, length = rate*5;
    const char* files[] = {"01-Dry.wav","02-Liquid-Skin.wav","03-Submerged.wav"};
    const int presets[] = {4,5,6};
    const int pattern[] = {48,55,60,64,55,60,67,64,53,60,65,69,60,65,72,69};
    for (int version = 0; version < 3; ++version)
    {
        std::ofstream stream(directory/files[version],std::ios::binary);
        if (! stream) return 1;
        stream.write("RIFF",4); integer(stream,36+static_cast<uint32_t>(length)*4,4); stream.write("WAVEfmt ",8);
        integer(stream,16,4); integer(stream,1,2); integer(stream,2,2); integer(stream,rate,4);
        integer(stream,rate*4,4); integer(stream,4,2); integer(stream,16,2);
        stream.write("data",4); integer(stream,static_cast<uint32_t>(length)*4,4);
        auto settings = patina::preset(presets[version]); settings.output = -2;
        patina::Texture texture; texture.prepare(rate,settings);
        float peak = 0;
        for (int i = 0; i < length; ++i)
        {
            const double time = static_cast<double>(i)/rate;
            const int step = static_cast<int>(time/0.4);
            float sample = 0;
            if (step < 8)
            {
                const double local = time-step*0.4;
                const double hz = 440*std::pow(2.0,(pattern[step]-69)/12.0);
                const double phase = local*hz*6.283185307179586;
                const double envelope = (1-std::exp(-local*700))*std::exp(-local*4.5)*std::clamp((0.4-local)/0.015,0.0,1.0);
                sample = static_cast<float>(0.17*envelope*(std::sin(phase)+0.32*std::sin(phase*2)+0.16*std::sin(phase*3)));
            }
            const auto output = texture.process(sample,sample*0.96f);
            for (float value : output)
            {
                peak = std::max(peak,std::abs(value));
                const auto pcm = static_cast<int16_t>(std::round(std::clamp(value,-1.0f,1.0f)*32767));
                integer(stream,static_cast<uint16_t>(pcm),2);
            }
        }
        if (peak >= 1) { std::cerr << "Example exceeded PCM headroom\n"; return 1; }
        stream.flush();
        if (! stream) { std::cerr << "Could not write example file\n"; return 1; }
        stream.close();
        if (std::filesystem::file_size(directory/files[version]) != 44+static_cast<uintmax_t>(length)*4)
        {
            std::cerr << "Incomplete example file\n";
            return 1;
        }
        std::cout << files[version] << " peak " << peak << '\n';
    }
}
