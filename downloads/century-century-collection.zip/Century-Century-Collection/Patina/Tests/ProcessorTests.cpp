#include "Processor.h"
#include <iostream>
#include <stdexcept>
void check(bool ok,const char* message) { if (! ok) throw std::runtime_error(message); }
int main(int argc,char** argv)
{
    juce::ScopedJuceInitialiser_GUI initialise;
    try
    {
        PatinaProcessor processor;
        check(processor.getNumPrograms() == 8 && processor.getCurrentProgram() == 5,"Liquid-focused factory default");
        check(std::abs(processor.settings().liquid-0.8f) < 0.0001f,"Liquid default parameter");
        processor.setCurrentProgram(4);
        processor.prepareToPlay(48000,512);
        juce::AudioBuffer<float> audio(2,512),original(2,512);
        juce::MidiBuffer midi;
        for (int channel = 0; channel < 2; ++channel)
            for (int i = 0; i < 512; ++i)
                audio.setSample(channel,i,static_cast<float>(0.3*std::sin(i*0.11+channel)));
        original.makeCopyOf(audio);
        processor.processBlock(audio,midi);
        for (int channel = 0; channel < 2; ++channel)
            for (int i = 0; i < 512; ++i)
                check(audio.getSample(channel,i) == original.getSample(channel,i),"Dry preset identity");
        processor.setCurrentProgram(2);
        processor.prepareToPlay(48000,512);
        double error = 0;
        for (int block = 0; block < 120; ++block)
        {
            audio.makeCopyOf(original); processor.processBlock(audio,midi);
            for (int i = 0; i < 512; ++i) error += std::abs(audio.getSample(0,i)-original.getSample(0,i));
        }
        check(error > 10,"Wet texture alters the input");
        juce::MemoryBlock saved; processor.getStateInformation(saved);
        PatinaProcessor restored; restored.setStateInformation(saved.getData(),static_cast<int>(saved.getSize()));
        check(restored.getCurrentProgram() == 2 && std::abs(restored.settings().drift-0.62f) < 0.0001f,"Preset and parameter state recall");
        auto legacy = processor.state.copyState();
        legacy.removeChild(legacy.getChildWithProperty("id","liquid"),nullptr);
        legacy.removeChild(legacy.getChildWithProperty("id","movement"),nullptr);
        auto legacyXml = legacy.createXml();
        juce::MemoryBlock legacyData;
        juce::AudioProcessor::copyXmlToBinary(*legacyXml,legacyData);
        PatinaProcessor migrated;
        migrated.setStateInformation(legacyData.getData(),static_cast<int>(legacyData.getSize()));
        check(std::abs(migrated.settings().liquid) < 0.0001f,"Old session state restores with Liquid disabled");
        audio.makeCopyOf(original); processor.processBlockBypassed(audio,midi);
        for (int channel = 0; channel < 2; ++channel)
            for (int i = 0; i < 512; ++i)
                check(audio.getSample(channel,i) == original.getSample(channel,i),"Host bypass passes input unchanged");
        auto layout = processor.getBusesLayout();
        layout.inputBuses.set(0,juce::AudioChannelSet::mono());
        layout.outputBuses.set(0,juce::AudioChannelSet::mono());
        check(processor.setBusesLayout(layout),"Mono bus supported");
        processor.prepareToPlay(44100,127);
        juce::AudioBuffer<float> mono(1,127);
        for (int i = 0; i < 127; ++i) mono.setSample(0,i,static_cast<float>(0.25*std::sin(i*0.17)));
        processor.processBlock(mono,midi);
        for (int i = 0; i < 127; ++i) check(std::isfinite(mono.getSample(0,i)),"Finite mono processing");
        processor.setCurrentProgram(5);
        processor.prepareToPlay(44100,127);
        for (int block = 0; block < 90; ++block)
        {
            for (int i = 0; i < 127; ++i) mono.setSample(0,i,static_cast<float>(0.25*std::sin((block*127+i)*0.17)));
            processor.processBlock(mono,midi);
            for (int i = 0; i < 127; ++i) check(std::isfinite(mono.getSample(0,i)),"Liquid preset finite on mono track");
        }
        if (argc == 3 && juce::String(argv[1]) == "--snapshot")
        {
            processor.setCurrentProgram(5);
            std::unique_ptr<juce::AudioProcessorEditor> editor(processor.createEditor());
            const auto image = editor->createComponentSnapshot(editor->getLocalBounds(),true,1.5f);
            juce::MemoryOutputStream stream;
            check(juce::PNGImageFormat().writeImageToStream(image,stream),"Editor render");
            check(juce::File(argv[2]).replaceWithData(stream.getData(),stream.getDataSize()),"Replace editor preview");
        }
        std::cout << "PASS: stereo/mono buses, dry identity, wet effect, state recall and host bypass\n";
        return 0;
    }
    catch (const std::exception& error) { std::cerr << "FAIL: " << error.what() << '\n'; return 1; }
}
