#include "Texture.h"
#include <iostream>
#include <stdexcept>
#include <limits>
#include <random>
void check(bool condition,const char* text) { if (! condition) throw std::runtime_error(text); }
int main()
{
    try
    {
        patina::Texture effect;
        effect.prepare(48000,patina::preset(4));
        for (int i = 0; i < 12000; ++i)
        {
            const float x = static_cast<float>(std::sin(i*0.17)*0.45), y = static_cast<float>(std::sin(i*0.23)*0.3);
            const auto out = effect.process(x,y);
            check(out[0] == x && out[1] == y,"Dry preset is sample-identical at unity output");
        }
        auto params = patina::preset(0);
        params.mix = 1; params.output = 0;
        params.dust = params.drive = params.drift = params.erosion = params.space = params.echo = 0;
        effect.prepare(48000,params);
        for (int i = 0; i < 10000; ++i)
        {
            const auto out = effect.process(0,0);
            check(out[0] == 0 && out[1] == 0,"Silence remains silent without dust");
        }
        patina::Texture a,b;
        a.prepare(44100,patina::preset(1)); b.prepare(44100,patina::preset(1));
        double difference = 0;
        for (int i = 0; i < 44100; ++i)
        {
            const float x = static_cast<float>(0.2*std::sin(i*0.04));
            const auto first = a.process(x,x), second = b.process(x,x);
            check(first == second,"Identical input and initial seed give reproducible processing");
            difference += std::abs(first[0]-x);
        }
        check(difference > 10,"Preset changes the sound");
        std::mt19937 random(7);
        double worst = 0;
        for (double rate : {8000.0,44100.0,48000.0,96000.0,192000.0})
        {
            effect.prepare(rate);
            for (int i = 0; i < static_cast<int>(rate*1.5); ++i)
            {
                if (i%1024 == 0)
                {
                    auto p = patina::preset(static_cast<int>(random()%8));
                    p.feedback = 0.78f; p.space = 1;
                    p.liquid = 1;
                    effect.set(p);
                }
                const float x = i%421 == 0 ? 1.0f : static_cast<float>(0.4*std::sin(i*0.05));
                for (float value : effect.process(x,-x*0.7f))
                {
                    check(std::isfinite(value),"Finite DSP under repeated parameter changes");
                    worst = std::max(worst,static_cast<double>(std::abs(value)));
                    check(std::abs(value) < 10,"Feedback remains bounded for normalized test signals");
                }
            }
        }
        params = patina::preset(6); params.mix = 1; params.output = 0; params.dust = 0; params.feedback = 0.78f; params.liquid = 1;
        effect.prepare(8000,params);
        effect.process(1,1);
        double tailEarly = 0, tailLate = 0;
        for (int i = 0; i < 8000*60; ++i)
        {
            const auto out = effect.process(0,0);
            const double energy = out[0]*out[0]+out[1]*out[1];
            if (i < 8000*3) tailEarly += energy;
            if (i > 8000*55) tailLate += energy;
        }
        check(tailEarly > 0.00001 && tailLate < tailEarly*0.000001,"Impulse produces a decaying tail");
        effect.reset();
        const auto zero = effect.process(0,0);
        check(zero[0] == 0 && zero[1] == 0,"Reset clears feedback and room state");
        const auto finite = effect.process(std::numeric_limits<float>::quiet_NaN(),std::numeric_limits<float>::infinity());
        check(std::isfinite(finite[0]) && std::isfinite(finite[1]),"Nonfinite input rejected");
        auto liquid = patina::preset(5), plain = liquid;
        liquid.drive = liquid.dust = liquid.drift = liquid.erosion = liquid.echo = liquid.space = 0;
        liquid.output = 0; liquid.mix = 1;
        plain = liquid; plain.liquid = 0;
        a.prepare(48000,liquid); b.prepare(48000,plain);
        double liquidChange = 0, stereoMotion = 0;
        for (int i = 0; i < 48000; ++i)
        {
            const float sample = static_cast<float>(0.25*std::sin(i*0.13));
            const auto wet = a.process(sample,sample), dry = b.process(sample,sample);
            liquidChange += std::abs(wet[0]-dry[0]);
            stereoMotion += std::abs(wet[0]-wet[1]);
        }
        check(liquidChange > 10 && stereoMotion > 10,"Liquid stage changes sound and generates stereo motion without dust or erosion");
        std::cout << "PASS: dry identity, silence, deterministic texture, sample-rate/automation stress, bounded feedback, tail decay, reset, finite input handling; observed peak " << worst << '\n';
        return 0;
    }
    catch (const std::exception& error) { std::cerr << "FAIL: " << error.what() << '\n'; return 1; }
}
