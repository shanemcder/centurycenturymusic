# Patina v0.2 — Liquid

A liquid texture effect for instruments, loops and vocals: swirling resonances, overlapping stereo chorus taps, softer transients, dark echoes and denser room diffusion. The original saturation, tape drift, dust and erosion controls remain available.

This revision responds to the requested wet/moist direction and the references Russian Dolls and Sunflower. The streaming recordings were located but not auditioned in this environment. The new presets are original interpretations of that description, not measured matches to the tracks.

## Start here

Load **Liquid Skin**, the new default, and try Mix around 45–65%. Raise Liquid for more swirl and smear. Try **Submerged** for a darker, more blended sound, or **Soft Bloom** for brighter motion. Keep Dust and Erosion near zero for a smooth surface. Movement controls how quickly the liquid texture shifts; 0.1–0.4 Hz is a gentle starting range.

The creative direction draws from intimate, weathered, spacious electronic textures associated with Nicolas Jaar. This is an original effect with no artist samples, affiliation, or claim to recreate his exact recordings. Choose a sound with an interesting performance first, then use Patina to give it a different surface and space.

## Build and install on your Mac

This download contains source, not a prebuilt Mac plugin. Use the CMake and Apple command line tools from your ChordPalette setup. Unzip into Downloads, then:

```bash
cd ~/Downloads/Patina
bash scripts/build-mac.sh
bash scripts/install-mac.sh
```

The build downloads JUCE 8.0.12 on first use. If needed, prerequisites are `xcode-select --install` and `brew install cmake`. To use your own JUCE checkout, configure with `cmake -S . -B build -DJUCE_DIR=/absolute/path/to/JUCE -DCMAKE_BUILD_TYPE=Release`, then build that folder.

The project builds an Audio Unit effect for Logic and a VST3 effect. It does not include a standalone app.

## Use in Logic Pro

1. Quit and reopen Logic after installation.
2. Load Patina in an **Audio FX** slot on a software instrument or audio track: **Audio Units > Century Century > Patina**.
3. Try **Liquid Skin** on a piano, plucked synth or guitar, or **Submerged** on a sparse chord pad or vocal.
4. Start with Mix around 45–65% for the wet direction, or lower it for subtle texture.
5. Use Output to compare processed and original sound at similar levels. The output meter changes colour when its measured peak exceeds 0 dBFS.
6. Automate Shade or Mix to make textures move through the arrangement. Adjusting Echo Time smoothly bends the repeats' pitch.

If Logic does not list the effect, rescan it in Plug-in Manager. Terminal validation:

```bash
auval -v aufx Ptnx Cnty
```

## Controls

| Control | What it does |
| --- | --- |
| Drive | Soft tanh saturation with approximate gain compensation; warmer and denser at higher settings |
| Liquid | Moving all-pass resonances, three modulated stereo delay taps and a soft film filter; also increases room diffusion and echo modulation |
| Movement | Liquid modulation rate from 0.05 to 2 Hz; faster values are more obviously animated |
| Drift | Blends in a micro-delay with slow wow and faster flutter; introduces pitch instability and some comb/chorus colour |
| Dust | Procedural low-frequency noise, hiss and random small crackles, following the input envelope |
| Erosion | Blended sample holding and bit quantization; gritty digital wear, including intentional aliasing |
| Shade | Low-pass cutoff from 500 Hz to 20 kHz; darkens the processed signal |
| Echo | Amount of filtered, cross-fed stereo repeats |
| Space | Amount and decay of a diffuse comb/all-pass room |
| Mix | Linear blend between original and processed sound |
| Echo Time | 40–1,200 ms; not tempo-synced |
| Feedback | Repeat regeneration, limited to 78% |
| Width | Width of the wet signal; 0% is mono wet, 50% retains its natural width, 100% doubles the side component |
| Output | Final gain trim, -18 to +6 dB, applied to the dry/wet blend |

All controls are exposed for DAW automation. Parameters are smoothed in the audio engine. Double-click a control to return to its Liquid Skin default. Numeric fields accept percentages, milliseconds, dB, and Hz/kHz as appropriate.

## Presets

- **Liquid Skin:** the new default; pronounced liquid motion, soft room and restrained grit.
- **Submerged:** darker, wetter and more blended, with slower motion.
- **Soft Bloom:** brighter, gentler chorus and diffuse ambience.
- **Soft Focus:** restrained warmth, drift and room, with a 30% mix.
- **Dusty Piano:** a darker, more worn surface with more dust and a little room.
- **Uneasy Tape:** stronger instability and digital erosion.
- **After Hours:** dark, spacious echoes around the original sound.
- **Dry / Clean:** Mix at 0% and Output at 0 dB; sample-identical pass-through from a fresh state.

Selecting a preset replaces the control values and turns off the plugin's own Bypass switch. The preset name identifies the last selected factory preset; it stays the same as you adjust controls. DAW session state recalls the controls, bypass state and preset selection.

The original five presets keep Liquid disabled. A saved v0.1 state without the new controls restores with Liquid at zero so upgrading does not silently add the new stage. Parameter IDs and the AU/VST3 identity are preserved; install v0.2 over v0.1. To use the new direction in an older session, explicitly choose one of the three new presets or raise Liquid.

The plugin's Bypass switch smoothly returns to dry unity output. Host bypass passes input directly and clears effect tails on entry. Noise fades with the input envelope rather than running continuously at full level. Dust is not a recorded vinyl sample or model of a specific tape machine. There is no freeze, granular slicing, tempo sync, oversampled distortion or brickwall limiter in this version. Echo/room addition and stereo widening can raise peaks; use Output or your DAW's gain/limiter when needed. The reported maximum tail is 60 seconds to cover the long-feedback settings.

## Audio comparison

The included `Examples` folder contains a short original synthetic plucked pattern rendered dry and through Liquid Skin / Submerged. All three use the same source and -2 dB output trim; the examples are not independently normalized. They demonstrate the effect, not Nicolas Jaar's audio. `RenderExamples.cpp` reproduces the files using the same DSP engine.

## Validation

See VALIDATION.md for the tests and host checks still needed. Linux build and synthetic-audio testing do not replace testing the Audio Unit in Logic on your Mac.

Dependency-free DSP tests:

```bash
cmake -S . -B build-tests -DPATINA_CORE_ONLY=ON
cmake --build build-tests
ctest --test-dir build-tests --output-on-failure
```

Patina source uses the MIT license in LICENSE. JUCE and its SDK dependencies retain their own licenses: https://github.com/juce-framework/JUCE/blob/8.0.12/LICENSE.md.
