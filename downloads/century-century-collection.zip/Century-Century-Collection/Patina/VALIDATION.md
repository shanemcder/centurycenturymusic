# Patina v0.2 validation

Development environment: Linux x86_64, GCC 13, JUCE 8.0.12.

Completed:

- Built the VST3 effect and ran the dependency-free DSP tests plus JUCE processor integration tests.
- Dry / Clean preset at unity Output is sample-identical to the input from a fresh DSP state.
- Silence remains silent with Dust disabled. Reset clears echo, room and noise state.
- Reproducible processing for the same input/settings/initial noise seed; factory texture changes the input.
- Automation/preset stress at 8, 44.1, 48, 96 and 192 kHz with maximum feedback, room and Liquid settings produced finite, bounded results for the tested normalized signals. This is not a guarantee of output peak levels for all inputs/settings.
- An impulse at full Liquid produced an echo/room tail which decayed substantially by the end of a 60-second test.
- NaN and infinite input samples were rejected by the core.
- Core tests passed AddressSanitizer and UndefinedBehaviorSanitizer. Leak detection was disabled because LeakSanitizer process inspection is unsupported here.
- Liquid alone changed a steady input and produced stereo motion with dust, erosion, echo and room disabled.
- JUCE integration tests verified stereo and mono operation, dry identity, changed wet output, preset/parameter state recall, v0.1 state migration with Liquid disabled, Liquid Skin defaults, finite mono Liquid processing and unchanged input under host bypass.
- Rendered and visually inspected the actual JUCE editor. The included preview is an editor render.
- Rendered three 5-second stereo PCM examples at 44.1 kHz from the same original synthetic source, using -2 dB Output trim. All example peaks remained below 0 dBFS; no independent normalization was applied.
- Mac build/install scripts passed shell syntax checks.

Not verified here: macOS AU compilation/auval, loading in Logic, host automation in a DAW, subjective listening with the user's sounds, or equivalence to an artist's production chain. Test Patina in Logic on your Mac after building it. VST3 build success on Linux does not establish compatibility with every VST3 host.

Known processing choices: distortion is not oversampled, Erosion intentionally aliases, Drift and Liquid blend variable delays, and Mix is linear. Liquid uses a moving six-stage all-pass cascade, three differently modulated chorus taps, transient-softening low-pass smoothing and additional room diffusion. The plugin reports no fixed latency; the variable delays are part of the effect. Parameters are smoothed, and no heap allocation is performed inside the core per-sample processing method. Output is not brickwall limited. Host bypass clears tails; the plugin's own Bypass switch smoothly targets dry unity output while internal states continue evolving.

The Russian Dolls and Sunflower streaming references were located but not listened to in this environment. The revision follows the user's wet/moist direction; no reference-audio matching, reverse engineering of artist processing or perceptual equivalence test is claimed.
