#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
if ! xcode-select -p >/dev/null 2>&1; then
    echo "Install Apple's command line tools: xcode-select --install"
    exit 1
fi
if ! command -v cmake >/dev/null 2>&1; then
    echo "Install CMake: brew install cmake"
    exit 1
fi
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build --config Release --parallel 2
ctest --test-dir build -C Release --output-on-failure
echo "Built Patina. Run: bash scripts/install-mac.sh"
