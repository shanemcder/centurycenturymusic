#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
if [ ! -d build/Patina_artefacts ]; then
    echo "Build first: bash scripts/build-mac.sh"
    exit 1
fi
au=$(find build/Patina_artefacts -type d -name 'Patina.component' -print -quit)
vst=$(find build/Patina_artefacts -type d -name 'Patina.vst3' -print -quit)
if [ -z "$au" ] || [ -z "$vst" ]; then
    echo "Build the AU and VST3 targets first"
    exit 1
fi
destination="$HOME/Library/Audio/Plug-Ins"
mkdir -p "$destination/Components" "$destination/VST3"
ditto "$au" "$destination/Components/Patina.component"
ditto "$vst" "$destination/VST3/Patina.vst3"
codesign --force --deep --sign - "$destination/Components/Patina.component"
codesign --force --deep --sign - "$destination/VST3/Patina.vst3"
echo "Installed Patina. Quit and reopen Logic Pro."
echo "AU validation: auval -v aufx Ptnx Cnty"
