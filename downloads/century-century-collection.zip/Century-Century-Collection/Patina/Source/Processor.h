#pragma once
#include <juce_audio_utils/juce_audio_utils.h>
#include "Texture.h"
class PatinaProcessor : public juce::AudioProcessor
{
public:
    PatinaProcessor();
    using juce::AudioProcessor::processBlock;
    using juce::AudioProcessor::processBlockBypassed;
    void prepareToPlay(double,int) override;
    void releaseResources() override {}
    void reset() override { texture.reset(); }
    void processBlock(juce::AudioBuffer<float>&,juce::MidiBuffer&) override;
    void processBlockBypassed(juce::AudioBuffer<float>&,juce::MidiBuffer&) override;
    bool isBusesLayoutSupported(const BusesLayout&) const override;
    const juce::String getName() const override { return "Patina"; }
    bool acceptsMidi() const override { return false; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override { return 60; }
    bool hasEditor() const override { return true; }
    juce::AudioProcessorEditor* createEditor() override;
    int getNumPrograms() override { return 8; }
    int getCurrentProgram() override { return selectedPreset.load(); }
    void setCurrentProgram(int) override;
    const juce::String getProgramName(int index) override { return patina::names[static_cast<size_t>(juce::jlimit(0,7,index))]; }
    void changeProgramName(int,const juce::String&) override {}
    void getStateInformation(juce::MemoryBlock&) override;
    void setStateInformation(const void*,int) override;
    patina::Settings settings() const;
    juce::AudioProcessorValueTreeState state;
    std::array<std::atomic<float>,96> scope {};
    std::atomic<float> inputPeak {0}, outputPeak {0};
private:
    static juce::AudioProcessorValueTreeState::ParameterLayout layout();
    patina::Texture texture;
    std::atomic<int> selectedPreset {5};
    bool hostBypassed = false;
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(PatinaProcessor)
};
