#pragma once
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <vector>

namespace patina
{
struct Settings
{
    float drive = 0.18f, drift = 0.12f, dust = 0.08f, erosion = 0;
    float shade = 7000, echo = 0.12f, space = 0.15f, mix = 0.3f;
    float time = 280, feedback = 0.32f, width = 0.5f, output = -1;
    float liquid = 0, movement = 0.18f;
};
inline constexpr std::array<const char*,14> ids
    {"drive","drift","dust","erosion","shade","echo","space","mix","time","feedback","width","output","liquid","movement"};
inline std::array<float,14> values(Settings p)
{
    return {p.drive,p.drift,p.dust,p.erosion,p.shade,p.echo,p.space,p.mix,p.time,p.feedback,p.width,p.output,p.liquid,p.movement};
}
inline Settings settings(const std::array<float,14>& p)
{
    return {p[0],p[1],p[2],p[3],p[4],p[5],p[6],p[7],p[8],p[9],p[10],p[11],p[12],p[13]};
}
inline constexpr std::array<const char*,8> names
    {"Soft Focus","Dusty Piano","Uneasy Tape","After Hours","Dry / Clean","Liquid Skin","Submerged","Soft Bloom"};
inline Settings preset(int index)
{
    switch(index)
    {
        case 1: return {0.28f,0.18f,0.34f,0.10f,4800,0.10f,0.25f,0.42f,190,0.28f,0.56f,-2};
        case 2: return {0.38f,0.62f,0.20f,0.25f,3200,0.24f,0.15f,0.55f,410,0.48f,0.66f,-3};
        case 3: return {0.16f,0.25f,0.12f,0.04f,2500,0.48f,0.48f,0.38f,620,0.55f,0.76f,-2};
        case 4: return {0,0,0,0,20000,0,0,0,280,0.32f,0.5f,0};
        case 5: return {0.10f,0.12f,0.01f,0,5500,0.28f,0.40f,0.60f,230,0.42f,0.62f,-2.5f,0.80f,0.22f};
        case 6: return {0.12f,0.16f,0,0,2800,0.40f,0.68f,0.72f,330,0.56f,0.65f,-3,0.92f,0.10f};
        case 7: return {0.06f,0.06f,0,0,8000,0.18f,0.32f,0.55f,160,0.32f,0.60f,-1.5f,0.52f,0.36f};
        default: return {};
    }
}
class Delay
{
public:
    void prepare(int length) { data.assign(static_cast<size_t>(std::max(4,length)),0); cursor = 0; }
    void clear() { std::fill(data.begin(),data.end(),0); cursor = 0; }
    void write(float value) { data[static_cast<size_t>(cursor)] = value; cursor = (cursor+1)%static_cast<int>(data.size()); }
    float read(double samples) const
    {
        const double position = static_cast<double>(cursor)-std::clamp(samples,1.0,static_cast<double>(data.size()-2));
        const int base = static_cast<int>(std::floor(position));
        const float fraction = static_cast<float>(position-base);
        const int length = static_cast<int>(data.size());
        const int a = (base%length+length)%length, b = (a+1)%length;
        return data[static_cast<size_t>(a)]*(1-fraction)+data[static_cast<size_t>(b)]*fraction;
    }
private:
    std::vector<float> data;
    int cursor = 0;
};
class Texture
{
public:
    void prepare(double sampleRate,Settings initial = {})
    {
        rate = std::max(8000.0,sampleRate);
        current = values(Settings{});
        set(initial);
        current = target;
        smooth = static_cast<float>(1-std::exp(-1/(rate*0.03)));
        envelopeCoefficient = static_cast<float>(std::exp(-1/(rate*0.3)));
        for (int channel = 0; channel < 2; ++channel)
        {
            tape[static_cast<size_t>(channel)].prepare(static_cast<int>(rate*0.04)+8);
            water[static_cast<size_t>(channel)].prepare(static_cast<int>(rate*0.07)+8);
            echo[static_cast<size_t>(channel)].prepare(static_cast<int>(rate*1.3)+8);
            for (int i = 0; i < 4; ++i)
                room[static_cast<size_t>(channel)][static_cast<size_t>(i)].prepare(static_cast<int>(rate*(roomTimes[i]+channel*0.0019))+4);
            for (int i = 0; i < 4; ++i)
                diffuse[static_cast<size_t>(channel)][static_cast<size_t>(i)].prepare(static_cast<int>(rate*(diffuseTimes[i]+channel*0.0007))+4);
        }
        reset();
    }
    void set(Settings parameters)
    {
        target = values(parameters);
        for (size_t i = 0; i < target.size(); ++i)
        {
            if (! std::isfinite(target[i])) target[i] = current[i];
            if (i == 4) target[i] = std::clamp(target[i],500.0f,20000.0f);
            else if (i == 8) target[i] = std::clamp(target[i],40.0f,1200.0f);
            else if (i == 9) target[i] = std::clamp(target[i],0.0f,0.78f);
            else if (i == 11) target[i] = std::clamp(target[i],-18.0f,6.0f);
            else if (i == 13) target[i] = std::clamp(target[i],0.05f,2.0f);
            else target[i] = std::clamp(target[i],0.0f,1.0f);
        }
    }
    void reset()
    {
        for (auto& line : tape) line.clear();
        for (auto& line : water) line.clear();
        for (auto& line : echo) line.clear();
        for (auto& channel : room) for (auto& line : channel) line.clear();
        for (auto& channel : diffuse) for (auto& line : channel) line.clear();
        low.fill(0); previous.fill(0); high.fill(0); echoDamp.fill(0); pink.fill(0);
        envelope.fill(0); crackle.fill(0); held.fill(0); holdCounter.fill(0);
        for (auto& channel : roomDamp) channel.fill(0);
        for (auto& channel : allpassState) channel.fill(0);
        phaseFeedback.fill(0); film.fill(0);
        phase = flutter = waterPhase = 0;
        random = 0x1234abcd;
    }
    std::array<float,2> process(float left,float right)
    {
        if (! std::isfinite(left)) left = 0;
        if (! std::isfinite(right)) right = 0;
        const std::array<float,2> input {left,right};
        for (size_t i = 0; i < current.size(); ++i) current[i] += smooth*(target[i]-current[i]);
        const auto p = settings(current);
        const float cutoff = std::min(p.shade,static_cast<float>(rate*0.45));
        const float pole = static_cast<float>(std::exp(-6.283185307179586*cutoff/rate));
        const float hp = static_cast<float>(std::exp(-6.283185307179586*25/rate));
        const float gain = 1+11*p.drive*p.drive;
        const float compensation = std::sqrt(gain);
        const double flutterAmount = std::sin(phase)*0.75+std::sin(flutter)*0.25;
        const double wowSamples = rate*(0.005+0.0035*p.drift*flutterAmount);
        std::array<float,2> coloured {}, delayed {}, result {};
        for (size_t channel = 0; channel < 2; ++channel)
        {
            float x = input[channel];
            envelope[channel] = std::max(std::abs(x),envelope[channel]*envelopeCoefficient);
            high[channel] = x-previous[channel]+hp*high[channel];
            previous[channel] = x;
            x = high[channel];
            const float saturated = std::tanh(x*gain)/compensation;
            x += p.drive*(saturated-x);
            low[channel] = (1-pole)*x+pole*low[channel];
            x = low[channel];
            tape[channel].write(x);
            const float drifted = tape[channel].read(wowSamples);
            x += p.drift*(drifted-x);
            if (p.erosion > 0.0001f)
            {
                const int hold = 1+static_cast<int>(p.erosion*p.erosion*23);
                if (++holdCounter[channel] >= hold)
                {
                    holdCounter[channel] = 0;
                    const float steps = std::pow(2.0f,16-12*p.erosion);
                    held[channel] = std::round(x*steps)/steps;
                }
                x += p.erosion*(held[channel]-x);
            }
            else { holdCounter[channel] = 0; held[channel] = x; }
            pink[channel] = 0.985f*pink[channel]+0.015f*noise();
            if (uniform() < p.dust*6.0/rate) crackle[channel] = noise()*0.08f*p.dust;
            const float follow = std::min(1.0f,envelope[channel]*8);
            x += follow*(pink[channel]*0.12f*p.dust+noise()*0.003f*p.dust+crackle[channel]);
            crackle[channel] *= 0.97f;
            // A moving all-pass cascade and three chorus taps create liquid motion.
            const double offset = static_cast<double>(channel)*1.7;
            const double wave = 0.5+0.5*std::sin(waterPhase+offset);
            const double centre = (110+1100*wave*wave)*(1+follow*0.7);
            float phased = x+p.liquid*0.42f*phaseFeedback[channel];
            static constexpr double ratios[] = {0.65,0.88,1.2,1.65,2.1,2.7};
            for (int stage = 0; stage < 6; ++stage)
            {
                const double frequency = std::min(rate*0.35,centre*ratios[stage]);
                const double tangent = std::tan(3.141592653589793*frequency/rate);
                const float coefficient = static_cast<float>((tangent-1)/(tangent+1));
                auto& state = allpassState[channel][static_cast<size_t>(stage)];
                const float y = coefficient*phased+state;
                state = phased-coefficient*y;
                phased = y;
            }
            phaseFeedback[channel] = 0.8f*phaseFeedback[channel]+0.2f*phased;
            const float swirled = x*0.65f+phased*0.35f;
            water[channel].write(swirled);
            float watery = swirled*0.25f;
            static constexpr double times[] = {0.012,0.023,0.034};
            static constexpr double speeds[] = {1.0,0.71,1.37};
            static constexpr float weights[] = {0.30f,0.25f,0.20f};
            for (int tap = 0; tap < 3; ++tap)
            {
                const double seconds = times[tap]+0.0025*p.liquid*std::sin(waterPhase*speeds[tap]+offset+tap*2.1);
                watery += weights[tap]*water[channel].read(rate*seconds);
            }
            film[channel] = 0.32f*watery+0.68f*film[channel];
            x += p.liquid*(film[channel]-x);
            coloured[channel] = x;
            delayed[channel] = echo[channel].read(rate*(p.time/1000.0+channel*0.009*p.width
                +0.0025*p.liquid*std::sin(waterPhase*0.72+offset)));
            echoDamp[channel] = 0.12f*delayed[channel]+0.88f*echoDamp[channel];
        }
        for (size_t channel = 0; channel < 2; ++channel)
        {
            const float feedbackSignal = 0.7f*echoDamp[channel]+0.3f*echoDamp[1-channel];
            echo[channel].write(std::tanh(coloured[channel]+p.feedback*feedbackSignal));
            float diffused = coloured[channel]+p.echo*delayed[channel]*0.5f;
            for (int i = 0; i < 4; ++i)
            {
                auto& line = diffuse[channel][static_cast<size_t>(i)];
                const float d = line.read(rate*(diffuseTimes[i]+static_cast<double>(channel)*0.0007));
                const float y = d-diffused*0.5f;
                line.write(diffused+d*0.5f);
                if (i < 2) diffused = y;
                else diffused += p.liquid*(y-diffused);
            }
            float roomSum = 0;
            const float decay = 0.4f+p.space*4.6f;
            for (int i = 0; i < 4; ++i)
            {
                auto& line = room[channel][static_cast<size_t>(i)];
                const double seconds = roomTimes[i]+static_cast<double>(channel)*0.0019;
                const float d = line.read(rate*seconds);
                auto& damp = roomDamp[channel][static_cast<size_t>(i)];
                damp = 0.25f*d+0.75f*damp;
                const float feedback = static_cast<float>(std::pow(10.0,-3*seconds/decay));
                line.write(diffused+damp*feedback);
                roomSum += d;
            }
            result[channel] = coloured[channel]+p.echo*delayed[channel]+p.space*roomSum*0.12f;
        }
        const float middle = (result[0]+result[1])*0.5f;
        const float side = (result[0]-result[1])*p.width;
        result = {middle+side,middle-side};
        const float outputGain = std::pow(10.0f,p.output/20.0f);
        for (size_t channel = 0; channel < 2; ++channel)
            result[channel] = (input[channel]*(1-p.mix)+result[channel]*p.mix)*outputGain;
        phase += 6.283185307179586*0.23/rate;
        flutter += 6.283185307179586*3.71/rate;
        waterPhase += 6.283185307179586*p.movement/rate;
        if (phase > 6.283185307179586) phase -= 6.283185307179586;
        if (flutter > 6.283185307179586) flutter -= 6.283185307179586;
        if (waterPhase > 6.283185307179586*1000) waterPhase -= 6.283185307179586*1000;
        return result;
    }
private:
    inline static constexpr double roomTimes[4] {0.0297,0.0371,0.0411,0.0437};
    inline static constexpr double diffuseTimes[4] {0.005,0.0017,0.0073,0.0029};
    double rate = 48000, phase = 0, flutter = 0, waterPhase = 0;
    float smooth = 0.001f, envelopeCoefficient = 0.999f;
    std::array<float,14> current {},target {};
    std::array<Delay,2> tape,echo,water;
    std::array<std::array<Delay,4>,2> room;
    std::array<std::array<Delay,4>,2> diffuse;
    std::array<std::array<float,6>,2> allpassState {};
    std::array<float,2> phaseFeedback {},film {};
    std::array<float,2> low {},previous {},high {},echoDamp {},pink {},envelope {},crackle {},held {};
    std::array<int,2> holdCounter {};
    std::array<std::array<float,4>,2> roomDamp {};
    uint32_t random = 0x1234abcd;
    double uniform()
    {
        random ^= random<<13; random ^= random>>17; random ^= random<<5;
        return static_cast<double>(random)/4294967296.0;
    }
    float noise() { return static_cast<float>(uniform()*2-1); }
};
}
