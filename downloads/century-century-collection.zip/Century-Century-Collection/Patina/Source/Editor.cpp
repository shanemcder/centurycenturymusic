#include "Editor.h"
namespace
{
const juce::Colour paper{0xff182323}, panel{0xff223131}, cream{0xffe7eee7}, muted{0xff9daea6}, copper{0xff8dcec0};
const char* names[] = {"DRIVE","DRIFT","DUST","EROSION","SHADE","ECHO","SPACE","MIX","ECHO TIME","FEEDBACK","WIDTH","OUTPUT","LIQUID","MOVEMENT"};
const char* descriptions[] = {"Soft saturation","Tape instability","Hiss and small crackles","Digital grit","Darken the top end","Soft stereo repeats","Diffuse room","Original / processed","","","","","Swirl, smear and flow","Speed of liquid motion"};
constexpr int mainControls[] = {0,12,1,4,7,2,3,5,6,13};
void label(juce::Graphics& g,const juce::String& text,int x,int y,int width)
{
    g.setColour(muted); g.setFont(juce::FontOptions(12.0f));
    g.drawText(text,x,y,width,20,juce::Justification::centredLeft);
}
}
PatinaLook::PatinaLook()
{
    setColour(juce::Slider::textBoxTextColourId,cream);
    setColour(juce::Slider::textBoxBackgroundColourId,panel);
    setColour(juce::Slider::textBoxOutlineColourId,juce::Colours::transparentBlack);
    setColour(juce::Slider::trackColourId,copper);
    setColour(juce::Slider::thumbColourId,cream);
    setColour(juce::ComboBox::backgroundColourId,panel);
    setColour(juce::ComboBox::textColourId,cream);
    setColour(juce::ComboBox::outlineColourId,muted.withAlpha(0.2f));
    setColour(juce::PopupMenu::backgroundColourId,panel);
    setColour(juce::PopupMenu::textColourId,cream);
    setColour(juce::PopupMenu::highlightedBackgroundColourId,copper);
    setColour(juce::PopupMenu::highlightedTextColourId,paper);
    setColour(juce::ToggleButton::textColourId,cream);
    setColour(juce::ToggleButton::tickColourId,copper);
    setColour(juce::ToggleButton::tickDisabledColourId,muted);
}
void PatinaLook::drawRotarySlider(juce::Graphics& g,int x,int y,int width,int height,float position,float begin,float end,juce::Slider&)
{
    const auto bounds = juce::Rectangle<float>(static_cast<float>(x),static_cast<float>(y),static_cast<float>(width),static_cast<float>(height)).reduced(9);
    const auto centre = bounds.getCentre();
    const float radius = std::min(bounds.getWidth(),bounds.getHeight())*0.5f;
    g.setColour(paper); g.fillEllipse(centre.x-radius+4,centre.y-radius+4,(radius-4)*2,(radius-4)*2);
    juce::Path arc;
    arc.addCentredArc(centre.x,centre.y,radius,radius,0,begin,end,true);
    g.setColour(muted.withAlpha(0.17f)); g.strokePath(arc,juce::PathStrokeType(3.0f));
    const float angle = begin+position*(end-begin);
    juce::Path active;
    active.addCentredArc(centre.x,centre.y,radius,radius,0,begin,angle,true);
    g.setColour(copper); g.strokePath(active,juce::PathStrokeType(3.0f));
    g.drawLine(centre.x+std::sin(angle)*radius*0.44f,centre.y-std::cos(angle)*radius*0.44f,
        centre.x+std::sin(angle)*radius*0.76f,centre.y-std::cos(angle)*radius*0.76f,2);
}
PatinaEditor::PatinaEditor(PatinaProcessor& p) : AudioProcessorEditor(p),processor(p)
{
    setLookAndFeel(&look);
    for (size_t i = 0; i < controls.size(); ++i)
    {
        auto& slider = controls[i];
        slider.setLookAndFeel(&look);
        slider.setSliderStyle(i < 8 || i >= 12 ? juce::Slider::RotaryHorizontalVerticalDrag : juce::Slider::LinearHorizontal);
        slider.setTextBoxStyle(juce::Slider::TextBoxBelow,false,112,24);
        slider.setColour(juce::Slider::textBoxTextColourId,cream);
        slider.setColour(juce::Slider::textBoxBackgroundColourId,panel);
        slider.textFromValueFunction = [i](double v)
        {
            if (i == 4) return v >= 1000 ? juce::String(v/1000,1)+" kHz" : juce::String(static_cast<int>(std::round(v)))+" Hz";
            if (i == 8) return juce::String(static_cast<int>(std::round(v)))+" ms";
            if (i == 11) return juce::String(v,1)+" dB";
            if (i == 13) return juce::String(v,2)+" Hz";
            return juce::String(static_cast<int>(std::round(v*100)))+"%";
        };
        slider.valueFromTextFunction = [i](const juce::String& text)
        {
            const double number = text.getDoubleValue();
            if (i == 4) return text.containsIgnoreCase("k") ? number*1000 : number;
            if (i == 8 || i == 11 || i == 13) return number;
            return number/100;
        };
        const auto format = slider.textFromValueFunction;
        const auto parse = slider.valueFromTextFunction;
        slider.setTooltip(i < 8 || i >= 12 ? descriptions[i] : i == 8 ? "Echo time in milliseconds; changes glide in pitch" : i == 9 ? "Repeat regeneration, limited to 78%" : i == 10 ? "Wet stereo width; 50% keeps its natural width" : "Final level trim; this effect has no brickwall limiter");
        addAndMakeVisible(slider);
        attachments.push_back(std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(processor.state,patina::ids[i],slider));
        slider.textFromValueFunction = format;
        slider.valueFromTextFunction = parse;
        slider.updateText();
        slider.setDoubleClickReturnValue(true,patina::values(patina::preset(5))[i]);
    }
    for (size_t i = 0; i < patina::names.size(); ++i) presets.addItem(patina::names[i],static_cast<int>(i)+1);
    presets.setSelectedId(processor.getCurrentProgram()+1,juce::dontSendNotification);
    presets.onChange = [this] { processor.setCurrentProgram(presets.getSelectedId()-1); };
    addAndMakeVisible(presets); addAndMakeVisible(bypass);
    bypassAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment>(processor.state,"bypass",bypass);
    setSize(1020,730);
    startTimerHz(24);
}
PatinaEditor::~PatinaEditor() { stopTimer(); setLookAndFeel(nullptr); }
void PatinaEditor::resized()
{
    presets.setBounds(733,43,235,34); bypass.setBounds(30,682,120,26);
    for (int i = 0; i < 10; ++i)
    {
        const int column = i%5, row = i/5;
        controls[static_cast<size_t>(mainControls[i])].setBounds(30+column*198,246+row*171,166,127);
    }
    for (size_t i = 8; i < 12; ++i)
        controls[i].setBounds(69+static_cast<int>(i-8)*250,615,160,52);
}
void PatinaEditor::paint(juce::Graphics& g)
{
    g.fillAll(paper);
    g.setColour(cream); g.setFont(juce::FontOptions(38.0f,juce::Font::bold));
    g.drawText("Patina",30,22,400,50,juce::Justification::centredLeft);
    label(g,"Liquid motion. Soft edges. Sound with a different surface.",32,76,680);
    label(g,"PRESET",733,20,235);
    g.setColour(panel); g.fillRoundedRectangle(20,116,980,99,12);
    label(g,"TEXTURE IN MOTION",32,126,380);
    juce::Path wave;
    for (size_t i = 0; i < processor.scope.size(); ++i)
    {
        const float x = 32+static_cast<float>(i)*640/static_cast<float>(processor.scope.size()-1);
        const float y = 177-juce::jlimit(-1.0f,1.0f,processor.scope[i].load())*27;
        if (i == 0) wave.startNewSubPath(x,y); else wave.lineTo(x,y);
    }
    g.setColour(copper); g.strokePath(wave,juce::PathStrokeType(1.4f));
    label(g,"IN  "+juce::String(juce::Decibels::gainToDecibels(processor.inputPeak.load(),-100.0f),1)+" dB",805,135,170);
    const float peak = processor.outputPeak.load();
    g.setColour(peak > 1 ? juce::Colour(0xffe6a09a) : muted); g.setFont(juce::FontOptions(12.0f));
    g.drawText("OUT  "+juce::String(juce::Decibels::gainToDecibels(peak,-100.0f),1)+" dB",805,165,170,20,juce::Justification::centredLeft);
    for (int i = 0; i < 10; ++i)
    {
        const int column = i%5, row = i/5, control = mainControls[i];
        g.setColour(cream); g.setFont(juce::FontOptions(13.0f,juce::Font::bold));
        g.drawText(names[control],28+column*198,226+row*171,170,20,juce::Justification::centred);
        g.setColour(muted); g.setFont(juce::FontOptions(11.0f));
        g.drawText(descriptions[control],20+column*198,375+row*171,185,20,juce::Justification::centred);
    }
    g.setColour(muted.withAlpha(0.16f)); g.drawHorizontalLine(586,30,990);
    for (int i = 8; i < 12; ++i)
        label(g,names[i],69+(i-8)*250,594,180);
    label(g,"Mono / stereo audio effect",250,685,310);
    label(g,"CENTURY CENTURY  /  v0.2",779,685,215);
}
