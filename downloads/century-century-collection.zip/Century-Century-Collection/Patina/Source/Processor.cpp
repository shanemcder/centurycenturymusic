#include "Processor.h"
#include "Editor.h"
juce::AudioProcessorValueTreeState::ParameterLayout PatinaProcessor::layout()
{
    juce::AudioProcessorValueTreeState::ParameterLayout result;
    const char* labels[] = {"Drive","Drift","Dust","Erosion","Shade","Echo","Space","Mix","Echo time","Feedback","Width","Output","Liquid","Movement"};
    const auto defaults = patina::values(patina::preset(5));
    for (size_t i = 0; i < defaults.size(); ++i)
    {
        juce::NormalisableRange<float> range(0,1,0.001f);
        if (i == 4) { range = {500,20000,1}; range.setSkewForCentre(4500); }
        if (i == 8) { range = {40,1200,1}; range.setSkewForCentre(300); }
        if (i == 9) range = {0,0.78f,0.001f};
        if (i == 11) range = {-18,6,0.1f};
        if (i == 13) range = {0.05f,2,0.001f};
        result.add(std::make_unique<juce::AudioParameterFloat>(juce::ParameterID{patina::ids[i],1},labels[i],range,defaults[i]));
    }
    result.add(std::make_unique<juce::AudioParameterBool>(juce::ParameterID{"bypass",1},"Bypass",false));
    return result;
}
PatinaProcessor::PatinaProcessor()
    : AudioProcessor(BusesProperties().withInput("Input",juce::AudioChannelSet::stereo(),true)
        .withOutput("Output",juce::AudioChannelSet::stereo(),true)),state(*this,nullptr,"Patina",layout()) {}
patina::Settings PatinaProcessor::settings() const
{
    std::array<float,14> p {};
    for (size_t i = 0; i < p.size(); ++i) p[i] = state.getRawParameterValue(patina::ids[i])->load();
    if (state.getRawParameterValue("bypass")->load() > 0.5f) { p[7] = 0; p[11] = 0; }
    return patina::settings(p);
}
void PatinaProcessor::prepareToPlay(double rate,int)
{
    texture.prepare(rate,settings());
    hostBypassed = false;
    for (auto& sample : scope) sample.store(0);
}
bool PatinaProcessor::isBusesLayoutSupported(const BusesLayout& buses) const
{
    const auto input = buses.getMainInputChannelSet();
    return (input == juce::AudioChannelSet::mono() || input == juce::AudioChannelSet::stereo())
        && buses.getMainOutputChannelSet() == input;
}
void PatinaProcessor::processBlock(juce::AudioBuffer<float>& audio,juce::MidiBuffer& midi)
{
    juce::ScopedNoDenormals guard;
    juce::ignoreUnused(midi);
    if (audio.getNumSamples() == 0 || audio.getNumChannels() == 0) return;
    hostBypassed = false;
    texture.set(settings());
    inputPeak.store(audio.getMagnitude(0,audio.getNumSamples()));
    const int channels = std::min(2,audio.getNumChannels());
    for (int i = 0; i < audio.getNumSamples(); ++i)
    {
        const float left = audio.getSample(0,i);
        const float right = channels == 2 ? audio.getSample(1,i) : left;
        const auto result = texture.process(left,right);
        audio.setSample(0,i,channels == 2 ? result[0] : (result[0]+result[1])*0.5f);
        if (channels == 2) audio.setSample(1,i,result[1]);
    }
    outputPeak.store(audio.getMagnitude(0,audio.getNumSamples()));
    for (size_t i = 0; i < scope.size(); ++i)
    {
        const int position = static_cast<int>(i)*audio.getNumSamples()/static_cast<int>(scope.size());
        scope[i].store(audio.getSample(0,std::min(position,audio.getNumSamples()-1)));
    }
}
void PatinaProcessor::processBlockBypassed(juce::AudioBuffer<float>& audio,juce::MidiBuffer& midi)
{
    juce::ignoreUnused(midi);
    if (! hostBypassed) texture.reset();
    hostBypassed = true;
    if (audio.getNumChannels() > 0 && audio.getNumSamples() > 0)
    {
        const float peak = audio.getMagnitude(0,audio.getNumSamples());
        inputPeak.store(peak); outputPeak.store(peak);
    }
}
void PatinaProcessor::setCurrentProgram(int index)
{
    index = juce::jlimit(0,7,index);
    selectedPreset.store(index);
    const auto values = patina::values(patina::preset(index));
    for (size_t i = 0; i < values.size(); ++i)
        if (auto* parameter = state.getParameter(patina::ids[i])) parameter->setValueNotifyingHost(parameter->convertTo0to1(values[i]));
    state.getParameter("bypass")->setValueNotifyingHost(0);
}
void PatinaProcessor::getStateInformation(juce::MemoryBlock& data)
{
    auto tree = state.copyState();
    tree.setProperty("preset",selectedPreset.load(),nullptr);
    if (auto xml = tree.createXml()) copyXmlToBinary(*xml,data);
}
void PatinaProcessor::setStateInformation(const void* data,int size)
{
    if (auto xml = getXmlFromBinary(data,size))
        if (xml->hasTagName("Patina"))
        {
            auto tree = juce::ValueTree::fromXml(*xml);
            if (! tree.getChildWithProperty("id","liquid").isValid())
            {
                juce::ValueTree liquid("PARAM");
                liquid.setProperty("id","liquid",nullptr);
                liquid.setProperty("value",0,nullptr);
                tree.addChild(liquid,-1,nullptr);
            }
            if (! tree.getChildWithProperty("id","movement").isValid())
            {
                juce::ValueTree movement("PARAM");
                movement.setProperty("id","movement",nullptr);
                movement.setProperty("value",0.18f,nullptr);
                tree.addChild(movement,-1,nullptr);
            }
            selectedPreset.store(juce::jlimit(0,7,static_cast<int>(tree.getProperty("preset",0))));
            state.replaceState(tree);
        }
}
juce::AudioProcessorEditor* PatinaProcessor::createEditor() { return new PatinaEditor(*this); }
juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter() { return new PatinaProcessor(); }
