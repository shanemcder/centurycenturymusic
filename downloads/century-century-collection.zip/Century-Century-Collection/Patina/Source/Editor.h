#pragma once
#include "Processor.h"
class PatinaLook : public juce::LookAndFeel_V4
{
public:
    PatinaLook();
    void drawRotarySlider(juce::Graphics&,int,int,int,int,float,float,float,juce::Slider&) override;
};
class PatinaEditor : public juce::AudioProcessorEditor, private juce::Timer
{
public:
    explicit PatinaEditor(PatinaProcessor&);
    ~PatinaEditor() override;
    void paint(juce::Graphics&) override;
    void resized() override;
private:
    PatinaProcessor& processor;
    PatinaLook look;
    juce::TooltipWindow tips {this,650};
    std::array<juce::Slider,14> controls;
    juce::ComboBox presets;
    juce::ToggleButton bypass {"Bypass"};
    std::vector<std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment>> attachments;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment> bypassAttachment;
    void timerCallback() override { presets.setSelectedId(processor.getCurrentProgram()+1,juce::dontSendNotification); repaint(); }
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(PatinaEditor)
};
