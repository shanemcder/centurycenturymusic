#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
if [ ! -d build/ChordPalette_artefacts ] || [ ! -d build/ChordPalettePlayer_artefacts ]; then
    echo "Build first: bash scripts/build-mac.sh"
    exit 1
fi
au=$(find build/ChordPalette_artefacts -type d -name 'ChordPalette.component' -print -quit)
vst=$(find build/ChordPalettePlayer_artefacts -type d -name 'ChordPalette Player.vst3' -print -quit)
if [ -z "$au" ] || [ -z "$vst" ]; then
    echo "Build first: bash scripts/build-mac.sh"
    exit 1
fi
destination="$HOME/Library/Audio/Plug-Ins"
mkdir -p "$destination/Components" "$destination/VST3"
ditto "$au" "$destination/Components/ChordPalette.component"
ditto "$vst" "$destination/VST3/ChordPalette Player.vst3"
codesign --force --deep --sign - "$destination/Components/ChordPalette.component"
codesign --force --deep --sign - "$destination/VST3/ChordPalette Player.vst3"
echo "Installed ChordPalette. Quit and reopen Logic Pro."
echo "Validate the Audio Unit with: auval -v aumi Chpl Cnty"
