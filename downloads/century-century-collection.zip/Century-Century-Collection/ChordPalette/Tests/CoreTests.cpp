#include "ChordEngine.h"
#include <iostream>
#include <random>
#include <stdexcept>
#include <vector>

struct Event { int channel; int pitch; bool down; int velocity; };
void check(bool ok, const char* description)
{
    if (! ok) throw std::runtime_error(description);
}
int main()
{
    try
    {
        cp::Settings settings;
        auto notes = cp::chord(settings);
        check(notes.size == 3 && notes.pitches[0] == 60 && notes.pitches[1] == 64 && notes.pitches[2] == 67, "C major");
        settings.inversion = 1;
        notes = cp::chord(settings);
        check(notes.pitches[0] == 64 && notes.pitches[1] == 67 && notes.pitches[2] == 72, "First inversion");
        settings = {9, 13, 4, 0, false};
        notes = cp::chord(settings);
        check(notes.size == 5 && notes.pitches[4] == 83 && cp::name(settings) == "Am9", "Minor ninth");
        notes = cp::chord({0, 11, 4, 3, false});
        check(notes.size == 4 && notes.pitches[0] == 74 && notes.pitches[3] == 84, "Add9 third inversion has ninth in bass");
        settings = {};
        check(cp::degree(0, false, 6, true, settings).quality == 9, "Major scale leading-tone seventh");
        check(cp::degree(9, true, 1, false, settings).root == 11, "Natural minor second degree");
        check(cp::degree(9, true, 4, true, settings).quality == 7, "Natural minor dominant is minor seventh");
        for (int root = 0; root < 12; ++root)
            for (int quality = 0; quality < 14; ++quality)
                for (int inversion = 0; inversion < 4; ++inversion)
                    for (int octave = 2; octave <= 6; ++octave)
                        for (int shift : {-60, 0, 67})
                        {
                            const auto generated = cp::chord({root, quality, octave, inversion, true}, shift);
                            for (int i = 0; i < generated.size; ++i)
                            {
                                check(generated.pitches[static_cast<size_t>(i)] >= 0 && generated.pitches[static_cast<size_t>(i)] <= 127, "Valid MIDI range");
                                if (i > 0) check(generated.pitches[static_cast<size_t>(i)] > generated.pitches[static_cast<size_t>(i - 1)], "Sorted unique voicing");
                            }
                        }
        cp::LiveEngine engine;
        std::vector<Event> events;
        auto emit = [&events](int channel, int pitch, bool down, int velocity) { events.push_back({channel, pitch, down, velocity}); };
        engine.noteOn(1, 60, 77, settings, emit);
        check(events.size() == 3 && events[0].velocity == 77, "Live chord and velocity");
        settings.root = 2;
        engine.noteOff(1, 60, emit);
        check(events.size() == 6 && events[3].pitch == 60 && ! events[3].down, "Release original voicing after parameter change");
        settings = {};
        events.clear();
        engine.noteOn(1, 60, 90, settings, emit);
        engine.noteOn(1, 62, 90, settings, emit);
        check(events.size() == 3, "Overlapping shared tones do not retrigger");
        engine.noteOff(1, 60, emit);
        check(events.size() == 3, "Shared tones survive first release");
        engine.noteOff(1, 62, emit);
        check(events.size() == 6, "Shared tones released once");
        events.clear();
        settings.transpose = true;
        engine.noteOn(2, 62, 111, settings, emit);
        check(events[0].pitch == 62 && events[0].channel == 2, "Transposition and channel");
        engine.sustain(2, true, emit);
        engine.noteOff(2, 62, emit);
        check(events.size() == 3, "Sustain holds generated notes");
        engine.sustain(2, false, emit);
        check(events.size() == 6, "Sustain release clears held notes");
        events.clear();
        settings = {};
        engine.preview(true, settings, 95, emit);
        engine.noteOn(1, 60, 90, settings, emit);
        engine.preview(false, settings, 95, emit);
        check(events.size() == 3, "Preview and live keys share note ownership");
        engine.panic(emit);
        check(events.size() == 6, "Panic releases every generated note");
        engine.noteOff(1, 60, emit);
        engine.panic(emit);
        check(events.size() == 6, "Late note-off and repeated panic are harmless");
        events.clear();
        engine.noteOn(1, 60, 90, settings, emit);
        engine.noteOn(1, 60, 90, settings, emit);
        engine.noteOff(1, 60, emit);
        check(events.size() == 12, "Repeated key-down has a balanced lifecycle");
        events.clear();
        engine.noteOn(1, 60, 90, settings, emit);
        engine.noteOn(2, 60, 90, settings, emit);
        engine.panicChannel(1, emit);
        check(events.size() == 9 && events[6].channel == 1, "Channel panic isolates channels");
        engine.noteOff(2, 60, emit);
        check(events.size() == 12, "Other channel still releases normally");
        engine.reset();
        std::array<std::array<int, 128>, 16> sounding {};
        auto audit = [&sounding](int channel, int pitch, bool down, int)
        {
            auto& active = sounding[static_cast<size_t>(channel - 1)][static_cast<size_t>(pitch)];
            check(down ? active == 0 : active == 1, "Random stream has balanced note ownership");
            active = down ? 1 : 0;
        };
        std::mt19937 random(42);
        for (int i = 0; i < 20000; ++i)
        {
            const int channel = static_cast<int>(random() % 16) + 1;
            const int key = static_cast<int>(random() % 128);
            const auto operation = random() % 6;
            settings = {static_cast<int>(random() % 12), static_cast<int>(random() % 14),
                        static_cast<int>(random() % 5) + 2, static_cast<int>(random() % 4), (random() % 2) != 0};
            if (operation == 0 || operation == 1) engine.noteOn(channel, key, 90, settings, audit);
            else if (operation == 2) engine.noteOff(channel, key, audit);
            else if (operation == 3) engine.sustain(channel, (random() % 2) != 0, audit);
            else if (operation == 4) engine.preview((random() % 2) != 0, settings, 90, audit);
            else engine.panicChannel(channel, audit);
        }
        engine.panic(audit);
        for (const auto& channel : sounding)
            for (int active : channel) check(active == 0, "No notes remain after randomized panic");
        std::cout << "PASS: chord voicings, scale degrees, 10,080 range cases, live triggering, transposition, velocity, channel isolation, sustain, overlap, preview, retrigger, panic\n";
        std::cout << "PASS: 20,000 randomized live events leave no hanging notes\n";
        return 0;
    }
    catch (const std::exception& error)
    {
        std::cerr << "FAIL: " << error.what() << '\n';
        return 1;
    }
}
