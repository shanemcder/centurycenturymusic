#include "PluginProcessor.h"
#include <iostream>
#include <stdexcept>

void check(bool condition, const char* text)
{
    if (! condition) throw std::runtime_error(text);
}
class TestPlayHead : public juce::AudioPlayHead
{
public:
    bool playing = true;
    juce::Optional<PositionInfo> getPosition() const override
    {
        PositionInfo position;
        position.setIsPlaying(playing);
        return position;
    }
};
int main(int argc, char** argv)
{
    juce::ScopedJuceInitialiser_GUI initialise;
    try
    {
        ChordPaletteProcessor processor;
        processor.prepareToPlay(48000.0, 512);
        juce::AudioBuffer<float> buffer(2, 512);
        juce::MidiBuffer midi;
        midi.addEvent(juce::MidiMessage::noteOn(3, 60, static_cast<juce::uint8>(101)), 21);
        processor.processBlock(buffer, midi);
        check(midi.getNumEvents() == 3, "Processor emits chord");
        for (const auto event : midi)
            check(event.samplePosition == 21 && event.getMessage().getChannel() == 3
                && event.getMessage().getVelocity() == 101, "Sample offset, channel and velocity retained");
        check(buffer.getMagnitude(0, buffer.getNumSamples()) > 0, "Player renders sound");
        processor.setParameter("root", 2);
        midi.clear();
        midi.addEvent(juce::MidiMessage::noteOff(3, 60), 84);
        processor.processBlock(buffer, midi);
        check(midi.getNumEvents() == 3, "Processor emits matching note-offs");
        auto iterator = midi.begin();
        check((*iterator).getMessage().getNoteNumber() == 60, "Original voicing released after chord change");
        processor.setParameter("root", 0);
        processor.setParameter("quality", 6);
        processor.setParameter("inversion", 1);
        processor.setParameter("length", 2);
        processor.setParameter("velocity", 88);
        const auto file = juce::File::getSpecialLocation(juce::File::tempDirectory).getNonexistentChildFile("ChordPalette-test", ".mid");
        check(processor.writeMidi(file), "MIDI write succeeds");
        juce::MidiFile decoded;
        {
            juce::FileInputStream stream(file);
            check(decoded.readFrom(stream), "MIDI file round-trip");
        }
        file.deleteFile();
        check(decoded.getTimeFormat() == 960 && decoded.getNumTracks() == 1, "Export resolution and tracks");
        int ons = 0, offs = 0;
        const auto* track = decoded.getTrack(0);
        for (int i = 0; i < track->getNumEvents(); ++i)
        {
            const auto& message = track->getEventPointer(i)->message;
            if (message.isNoteOn())
            {
                ++ons;
                check(std::abs(message.getTimeStamp()) < 0.000001 && message.getVelocity() == 88, "MIDI note-on timing and velocity");
                check(message.getNoteNumber() == 64 || message.getNoteNumber() == 67
                    || message.getNoteNumber() == 71 || message.getNoteNumber() == 72, "Export inversion pitches");
            }
            if (message.isNoteOff()) { ++offs; check(std::abs(message.getTimeStamp() - 3840.0) < 0.000001, "Four-beat export duration"); }
            check(! message.isTempoMetaEvent(), "No project tempo override");
        }
        check(ons == 4 && offs == 4, "Complete exported major seventh chord");
        processor.setParameter("monitor", 0);
        processor.setPreview(true);
        midi.clear();
        processor.processBlock(buffer, midi);
        check(midi.getNumEvents() == 4 && buffer.getMagnitude(0, buffer.getNumSamples()) < 0.000001f, "Preview outputs MIDI with monitor off");
        processor.setPreview(false);
        midi.clear();
        processor.processBlock(buffer, midi);
        check(midi.getNumEvents() == 4, "Preview release outputs note-offs");
        juce::MemoryBlock saved;
        processor.getStateInformation(saved);
        ChordPaletteProcessor restored;
        restored.setStateInformation(saved.getData(), static_cast<int>(saved.getSize()));
        check(static_cast<int>(restored.value("quality")) == 6 && static_cast<int>(restored.value("inversion")) == 1
            && static_cast<int>(restored.value("velocity")) == 88, "DAW state round-trip");
        midi.clear();
        midi.addEvent(juce::MidiMessage::noteOn(1, 60, static_cast<juce::uint8>(90)), 0);
        processor.processBlock(buffer, midi);
        midi.clear();
        midi.addEvent(juce::MidiMessage::noteOn(1, 62, static_cast<juce::uint8>(90)), 30);
        processor.processBlockBypassed(buffer, midi);
        check(midi.getNumEvents() == 5, "Bypass releases generated chord and preserves incoming key");
        TestPlayHead playhead;
        processor.setPlayHead(&playhead);
        midi.clear();
        midi.addEvent(juce::MidiMessage::noteOn(1, 60, static_cast<juce::uint8>(90)), 0);
        processor.processBlock(buffer, midi);
        playhead.playing = false;
        midi.clear();
        processor.processBlock(buffer, midi);
        check(midi.getNumEvents() == 4, "Stopping transport releases generated notes");
        processor.setPlayHead(nullptr);
        if (argc == 3 && juce::String(argv[1]) == "--snapshot")
        {
            processor.setParameter("monitor", 1);
            processor.setParameter("root", 0);
            processor.setParameter("quality", 6);
            processor.setParameter("seventh", 1);
            processor.setParameter("inversion", 0);
            std::unique_ptr<juce::AudioProcessorEditor> editor(processor.createEditor());
            const auto image = editor->createComponentSnapshot(editor->getLocalBounds(), true, 1.5f);
            juce::FileOutputStream stream{juce::File(argv[2])};
            check(stream.openedOk() && juce::PNGImageFormat().writeImageToStream(image, stream), "Editor snapshot");
        }
        std::cout << "PASS: processor timing, MIDI export round-trip, audio preview, MIDI-only monitor, state restore, bypass and transport stop\n";
        return 0;
    }
    catch (const std::exception& error)
    {
        std::cerr << "FAIL: " << error.what() << '\n';
        return 1;
    }
}
