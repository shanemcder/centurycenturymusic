#pragma once
#include "PluginProcessor.h"

class PaletteLook : public juce::LookAndFeel_V4
{
public:
    PaletteLook();
    void drawButtonBackground(juce::Graphics&, juce::Button&, const juce::Colour&, bool, bool) override;
    void drawComboBox(juce::Graphics&, int, int, bool, int, int, int, int, juce::ComboBox&) override;
};
class MidiDragButton : public juce::TextButton
{
public:
    std::function<void()> beginDrag;
    void mouseDown(const juce::MouseEvent& e) override { dragged = false; juce::TextButton::mouseDown(e); }
    void mouseDrag(const juce::MouseEvent& e) override
    {
        if (! dragged && e.getDistanceFromDragStart() > 6)
        {
            dragged = true;
            if (beginDrag) beginDrag();
        }
    }
private:
    bool dragged = false;
};
class ChordPaletteEditor : public juce::AudioProcessorEditor, private juce::Timer
{
public:
    explicit ChordPaletteEditor(ChordPaletteProcessor&);
    ~ChordPaletteEditor() override;
    void paint(juce::Graphics&) override;
    void resized() override;
private:
    ChordPaletteProcessor& processor;
    PaletteLook look;
    juce::TooltipWindow tips {this, 600};
    juce::ComboBox key, scale, sevenths, root, quality, octave, inversion, mode, velocity, length, monitor;
    std::array<juce::TextButton, 7> degrees;
    juce::TextButton audition {"Hold to audition"}, save {"Save MIDI..."}, panic {"Stop all notes"};
    MidiDragButton drag;
    std::vector<std::unique_ptr<juce::AudioProcessorValueTreeState::ComboBoxAttachment>> attachments;
    std::unique_ptr<juce::FileChooser> chooser;
    juce::String status {"Pick a chord. Hear it. Make it yours."};
    void connect(juce::ComboBox&, const char*, const juce::StringArray&);
    void timerCallback() override;
    void exportMidi();
    void dragMidi();
    void keyboard(juce::Graphics&, juce::Rectangle<float>);
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(ChordPaletteEditor)
};
