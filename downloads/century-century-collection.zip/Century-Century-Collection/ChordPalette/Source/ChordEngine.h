#pragma once
#include <algorithm>
#include <array>
#include <string>

namespace cp
{
struct Notes
{
    std::array<int, 6> pitches {};
    int size = 0;
};
struct Settings
{
    int root = 0;
    int quality = 0;
    int octave = 4;
    int inversion = 0;
    bool transpose = false;
};
inline constexpr std::array<const char*, 12> roots
    { "C", "C#", "D", "Eb", "E", "F", "F#", "G", "Ab", "A", "Bb", "B" };
inline constexpr std::array<const char*, 14> qualities
    { "Major", "Minor", "Diminished", "Augmented", "Sus2", "Sus4", "Major 7", "Minor 7",
      "Dominant 7", "Half-diminished 7", "Diminished 7", "Add9", "Major 9", "Minor 9" };
inline constexpr std::array<const char*, 14> suffixes
    { "", "m", "dim", "aug", "sus2", "sus4", "maj7", "m7", "7", "m7b5", "dim7", "add9", "maj9", "m9" };
inline Notes chord(Settings s, int shift = 0)
{
    static constexpr int intervals[14][6] =
    {
        {0,4,7}, {0,3,7}, {0,3,6}, {0,4,8}, {0,2,7}, {0,5,7}, {0,4,7,11},
        {0,3,7,10}, {0,4,7,10}, {0,3,6,10}, {0,3,6,9}, {0,4,7,14}, {0,4,7,11,14}, {0,3,7,10,14}
    };
    static constexpr int sizes[] = {3,3,3,3,3,3,4,4,4,4,4,4,5,5};
    const int quality = std::clamp(s.quality, 0, 13);
    const int size = sizes[quality];
    const int inversion = std::clamp(s.inversion, 0, size - 1);
    std::array<int, 6> pitches {};
    const int base = 12 * (std::clamp(s.octave, 2, 6) + 1) + std::clamp(s.root, 0, 11);
    const int bass = base + intervals[quality][inversion];
    for (int i = 0; i < size; ++i)
    {
        int pitch = base + intervals[quality][i];
        while (pitch < bass) pitch += 12;
        pitches[static_cast<size_t>(i)] = pitch + shift;
    }
    for (int i = 1; i < size; ++i)
        for (int j = i; j > 0 && pitches[static_cast<size_t>(j)] < pitches[static_cast<size_t>(j - 1)]; --j)
            std::swap(pitches[static_cast<size_t>(j)], pitches[static_cast<size_t>(j - 1)]);
    Notes result;
    for (int i = 0; i < size; ++i)
    {
        const int pitch = pitches[static_cast<size_t>(i)];
        if (pitch >= 0 && pitch <= 127)
            result.pitches[static_cast<size_t>(result.size++)] = pitch;
    }
    return result;
}
inline std::string name(Settings s)
{
    return std::string(roots[static_cast<size_t>(std::clamp(s.root, 0, 11))])
        + suffixes[static_cast<size_t>(std::clamp(s.quality, 0, 13))];
}
inline Settings degree(int key, bool minor, int degreeNumber, bool seventh, Settings current)
{
    static constexpr int majorSteps[] = {0,2,4,5,7,9,11};
    static constexpr int minorSteps[] = {0,2,3,5,7,8,10};
    static constexpr int majorTriads[] = {0,1,1,0,0,1,2};
    static constexpr int minorTriads[] = {1,2,0,1,1,0,0};
    static constexpr int majorSevenths[] = {6,7,7,6,8,7,9};
    static constexpr int minorSevenths[] = {7,9,6,7,7,6,8};
    const int d = std::clamp(degreeNumber, 0, 6);
    current.root = (key + (minor ? minorSteps[d] : majorSteps[d])) % 12;
    current.quality = seventh ? (minor ? minorSevenths[d] : majorSevenths[d])
                              : (minor ? minorTriads[d] : majorTriads[d]);
    return current;
}
// Retain the exact voicing for every held key; shared tones are reference counted.
class LiveEngine
{
public:
    template<class Emit> void noteOn(int channel, int key, int velocity, Settings settings, Emit emit)
    {
        if (! valid(channel, key)) return;
        auto& slot = held[static_cast<size_t>(channel - 1)][static_cast<size_t>(key)];
        release(channel, slot, emit);
        slot.notes = chord(settings, settings.transpose ? key - 60 : 0);
        slot.active = true;
        slot.down = true;
        acquire(channel, slot.notes, velocity, emit);
    }
    template<class Emit> void noteOff(int channel, int key, Emit emit)
    {
        if (! valid(channel, key)) return;
        auto& slot = held[static_cast<size_t>(channel - 1)][static_cast<size_t>(key)];
        slot.down = false;
        if (! pedal[static_cast<size_t>(channel - 1)]) release(channel, slot, emit);
    }
    template<class Emit> void sustain(int channel, bool down, Emit emit)
    {
        if (channel < 1 || channel > 16) return;
        pedal[static_cast<size_t>(channel - 1)] = down;
        if (! down)
            for (auto& slot : held[static_cast<size_t>(channel - 1)])
                if (! slot.down) release(channel, slot, emit);
    }
    template<class Emit> void preview(bool down, Settings settings, int velocity, Emit emit)
    {
        if (down == previewSlot.active) return;
        if (down)
        {
            previewSlot.notes = chord(settings);
            previewSlot.active = true;
            acquire(1, previewSlot.notes, velocity, emit);
        }
        else release(1, previewSlot, emit);
    }
    template<class Emit> void panicChannel(int channel, Emit emit)
    {
        if (channel < 1 || channel > 16) return;
        for (auto& slot : held[static_cast<size_t>(channel - 1)]) release(channel, slot, emit);
        if (channel == 1) release(1, previewSlot, emit);
        pedal[static_cast<size_t>(channel - 1)] = false;
    }
    template<class Emit> void panic(Emit emit)
    {
        for (int channel = 1; channel <= 16; ++channel) panicChannel(channel, emit);
    }
    void reset() { *this = LiveEngine {}; }
private:
    struct Slot { Notes notes; bool active = false; bool down = false; };
    std::array<std::array<Slot, 128>, 16> held {};
    std::array<std::array<int, 128>, 16> references {};
    std::array<bool, 16> pedal {};
    Slot previewSlot;
    static bool valid(int channel, int key) { return channel >= 1 && channel <= 16 && key >= 0 && key <= 127; }
    template<class Emit> void acquire(int channel, const Notes& notes, int velocity, Emit emit)
    {
        for (int i = 0; i < notes.size; ++i)
        {
            const int pitch = notes.pitches[static_cast<size_t>(i)];
            if (references[static_cast<size_t>(channel - 1)][static_cast<size_t>(pitch)]++ == 0)
                emit(channel, pitch, true, std::clamp(velocity, 1, 127));
        }
    }
    template<class Emit> void release(int channel, Slot& slot, Emit emit)
    {
        if (! slot.active) return;
        for (int i = 0; i < slot.notes.size; ++i)
        {
            const int pitch = slot.notes.pitches[static_cast<size_t>(i)];
            auto& count = references[static_cast<size_t>(channel - 1)][static_cast<size_t>(pitch)];
            if (--count == 0) emit(channel, pitch, false, 0);
        }
        slot = {};
    }
};
}
