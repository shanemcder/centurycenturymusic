#include "PluginProcessor.h"
#include "PluginEditor.h"

namespace
{
class PaletteSound : public juce::SynthesiserSound
{
public:
    bool appliesToNote(int) override { return true; }
    bool appliesToChannel(int) override { return true; }
};
class PaletteVoice : public juce::SynthesiserVoice
{
public:
    using juce::SynthesiserVoice::renderNextBlock;
    bool canPlaySound(juce::SynthesiserSound* sound) override { return dynamic_cast<PaletteSound*>(sound) != nullptr; }
    void startNote(int note, float velocity, juce::SynthesiserSound*, int) override
    {
        phase = 0;
        increment = juce::MathConstants<double>::twoPi * juce::MidiMessage::getMidiNoteInHertz(note) / getSampleRate();
        level = velocity * 0.075f;
        envelope.setSampleRate(getSampleRate());
        envelope.setParameters({0.012f, 0.18f, 0.7f, 0.22f});
        envelope.noteOn();
    }
    void stopNote(float, bool tail) override
    {
        if (tail) envelope.noteOff();
        else { envelope.reset(); clearCurrentNote(); }
    }
    void pitchWheelMoved(int) override {}
    void controllerMoved(int, int) override {}
    void renderNextBlock(juce::AudioBuffer<float>& buffer, int start, int count) override
    {
        for (int i = 0; i < count && isVoiceActive(); ++i)
        {
            const float sample = static_cast<float>(std::sin(phase) + 0.18 * std::sin(phase * 2.0))
                * level * envelope.getNextSample();
            phase += increment;
            if (phase >= juce::MathConstants<double>::twoPi) phase -= juce::MathConstants<double>::twoPi;
            for (int channel = 0; channel < buffer.getNumChannels(); ++channel)
                buffer.addSample(channel, start + i, sample);
            if (! envelope.isActive()) clearCurrentNote();
        }
    }
private:
    double phase = 0, increment = 0;
    float level = 0;
    juce::ADSR envelope;
};
}

juce::AudioProcessorValueTreeState::ParameterLayout ChordPaletteProcessor::layout()
{
    juce::AudioProcessorValueTreeState::ParameterLayout result;
    auto integer = [&result](const char* id, const char* title, int low, int high, int initial)
    {
        result.add(std::make_unique<juce::AudioParameterInt>(juce::ParameterID{id, 1}, title, low, high, initial));
    };
    integer("root", "Chord root", 0, 11, 0);
    integer("quality", "Chord type", 0, 13, 0);
    integer("key", "Key", 0, 11, 0);
    integer("scale", "Scale", 0, 1, 0);
    integer("seventh", "Palette sevenths", 0, 1, 0);
    integer("octave", "Octave", 2, 6, 4);
    integer("inversion", "Inversion", 0, 3, 0);
    integer("mode", "Live mode", 0, 1, 0);
    integer("velocity", "Preview and export velocity", 1, 127, 90);
    integer("length", "Export length", 0, 3, 2);
    integer("monitor", "Built-in sound", 0, 1, 1);
    return result;
}
ChordPaletteProcessor::ChordPaletteProcessor()
    : AudioProcessor(
#if CHORDPALETTE_AUDIO_PREVIEW
        BusesProperties().withOutput("Output", juce::AudioChannelSet::stereo(), true)
#else
        BusesProperties()
#endif
      ), state(*this, nullptr, "ChordPalette", layout())
{
    output.ensureSize(65536);
#if CHORDPALETTE_AUDIO_PREVIEW
    for (int i = 0; i < 32; ++i) synth.addVoice(new PaletteVoice());
    synth.addSound(new PaletteSound());
#endif
}
float ChordPaletteProcessor::value(const juce::String& id) const
{
    return state.getRawParameterValue(id)->load();
}
void ChordPaletteProcessor::setParameter(const juce::String& id, float v)
{
    if (auto* parameter = state.getParameter(id))
    {
        parameter->beginChangeGesture();
        parameter->setValueNotifyingHost(parameter->convertTo0to1(v));
        parameter->endChangeGesture();
    }
}
cp::Settings ChordPaletteProcessor::settings() const
{
    return {static_cast<int>(value("root")), static_cast<int>(value("quality")),
            static_cast<int>(value("octave")), static_cast<int>(value("inversion")), value("mode") > 0.5f};
}
void ChordPaletteProcessor::prepareToPlay(double rate, int)
{
    live.reset();
    wasPlaying = false;
    previewDown.store(false);
    synth.setCurrentPlaybackSampleRate(rate);
    synth.allNotesOff(0, false);
}
void ChordPaletteProcessor::releaseResources()
{
    previewDown.store(false);
    panicRequested.store(true);
    synth.allNotesOff(0, false);
}
bool ChordPaletteProcessor::isBusesLayoutSupported(const BusesLayout& buses) const
{
#if CHORDPALETTE_AUDIO_PREVIEW
    return buses.getMainInputChannelSet().isDisabled()
        && (buses.getMainOutputChannelSet() == juce::AudioChannelSet::mono()
            || buses.getMainOutputChannelSet() == juce::AudioChannelSet::stereo());
#else
    juce::ignoreUnused(buses);
    return true;
#endif
}
void ChordPaletteProcessor::processBlock(juce::AudioBuffer<float>& buffer, juce::MidiBuffer& midi)
{
    juce::ScopedNoDenormals guard;
    buffer.clear();
    output.clear();
    if (buffer.getNumSamples() <= 0) return;
    int position = 0;
    auto emit = [this, &position](int channel, int pitch, bool down, int velocity)
    {
        output.addEvent(down ? juce::MidiMessage::noteOn(channel, pitch, static_cast<juce::uint8>(velocity))
                             : juce::MidiMessage::noteOff(channel, pitch), position);
    };
    bool playing = false;
    if (auto* playhead = getPlayHead())
        if (auto info = playhead->getPosition()) playing = info->getIsPlaying();
    if (panicRequested.exchange(false) || (wasPlaying && ! playing))
    {
        live.panic(emit);
        previewDown.store(false);
    }
    wasPlaying = playing;
    const auto selected = settings();
    live.preview(previewDown.load(), selected, static_cast<int>(value("velocity")), emit);
    for (const auto metadata : midi)
    {
        const auto message = metadata.getMessage();
        position = juce::jlimit(0, buffer.getNumSamples() - 1, metadata.samplePosition);
        const int channel = message.getChannel();
        if (message.isNoteOn()) live.noteOn(channel, message.getNoteNumber(), message.getVelocity(), selected, emit);
        else if (message.isNoteOff()) live.noteOff(channel, message.getNoteNumber(), emit);
        else if (message.isController() && message.getControllerNumber() == 64)
            live.sustain(channel, message.getControllerValue() >= 64, emit);
        else if (message.isAllNotesOff() || message.isAllSoundOff())
        {
            live.panicChannel(channel, emit);
            output.addEvent(message, position);
        }
        else
        {
            if (message.isController() && message.getControllerNumber() == 121)
                live.sustain(channel, false, emit);
            output.addEvent(message, position);
        }
    }
    midi.swapWith(output);
#if CHORDPALETTE_AUDIO_PREVIEW
    synth.renderNextBlock(buffer, midi, 0, buffer.getNumSamples());
    if (value("monitor") < 0.5f) buffer.clear();
#endif
}
void ChordPaletteProcessor::processBlockBypassed(juce::AudioBuffer<float>& buffer, juce::MidiBuffer& midi)
{
    auto emit = [&midi](int channel, int pitch, bool down, int velocity)
    {
        juce::ignoreUnused(down, velocity);
        midi.addEvent(juce::MidiMessage::noteOff(channel, pitch), 0);
    };
    live.panic(emit);
    previewDown.store(false);
    synth.allNotesOff(0, false);
    buffer.clear();
}
void ChordPaletteProcessor::getStateInformation(juce::MemoryBlock& data)
{
    if (auto xml = state.copyState().createXml()) copyXmlToBinary(*xml, data);
}
void ChordPaletteProcessor::setStateInformation(const void* data, int size)
{
    if (auto xml = getXmlFromBinary(data, size))
        if (xml->hasTagName(state.state.getType()))
        {
            state.replaceState(juce::ValueTree::fromXml(*xml));
            panic();
        }
}
bool ChordPaletteProcessor::writeMidi(const juce::File& file) const
{
    const auto notes = cp::chord(settings());
    const double lengths[] = {1, 2, 4, 8};
    const double end = lengths[juce::jlimit(0, 3, static_cast<int>(value("length")))] * 960.0;
    juce::MidiMessageSequence track;
    auto title = juce::MidiMessage::textMetaEvent(3, cp::name(settings()));
    track.addEvent(title, 0);
    for (int i = 0; i < notes.size; ++i)
    {
        track.addEvent(juce::MidiMessage::noteOn(1, notes.pitches[static_cast<size_t>(i)],
            static_cast<juce::uint8>(value("velocity"))), 0);
        track.addEvent(juce::MidiMessage::noteOff(1, notes.pitches[static_cast<size_t>(i)]), end);
    }
    track.updateMatchedPairs();
    juce::MidiFile midi;
    midi.setTicksPerQuarterNote(960);
    midi.addTrack(track);
    juce::TemporaryFile temporary(file);
    bool written = false;
    {
        juce::FileOutputStream stream(temporary.getFile());
        if (stream.openedOk())
        {
            written = midi.writeTo(stream, 0);
            stream.flush();
            written = written && stream.getStatus().wasOk();
        }
    }
    return written && temporary.overwriteTargetFileWithTemporary();
}
juce::AudioProcessorEditor* ChordPaletteProcessor::createEditor() { return new ChordPaletteEditor(*this); }
juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter() { return new ChordPaletteProcessor(); }
