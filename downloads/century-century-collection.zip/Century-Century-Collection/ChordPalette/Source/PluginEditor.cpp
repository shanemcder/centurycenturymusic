#include "PluginEditor.h"

namespace
{
const juce::Colour ink {0xff213d35}, muted {0xff728179}, accent {0xffbde4cc}, paper {0xfff3f5ee};
void label(juce::Graphics& g, const juce::String& text, int x, int y, int width)
{
    g.setColour(muted);
    g.setFont(juce::FontOptions(12.0f));
    g.drawText(text, x, y, width, 18, juce::Justification::centredLeft);
}
}
PaletteLook::PaletteLook()
{
    setColour(juce::ComboBox::textColourId, ink);
    setColour(juce::PopupMenu::backgroundColourId, paper);
    setColour(juce::PopupMenu::textColourId, ink);
    setColour(juce::PopupMenu::highlightedBackgroundColourId, accent);
    setColour(juce::PopupMenu::highlightedTextColourId, ink);
    setColour(juce::TextButton::textColourOffId, ink);
    setColour(juce::TextButton::textColourOnId, ink);
    setColour(juce::TextButton::buttonColourId, juce::Colours::white);
}
void PaletteLook::drawButtonBackground(juce::Graphics& g, juce::Button& button, const juce::Colour& colour, bool hover, bool down)
{
    const auto area = button.getLocalBounds().toFloat().reduced(0.5f);
    const auto base = button.getToggleState() ? accent : colour;
    g.setColour(down ? base.darker(0.10f) : hover ? base.darker(0.035f) : base);
    g.fillRoundedRectangle(area, 10);
    g.setColour(ink.withAlpha(0.10f));
    g.drawRoundedRectangle(area, 10, 1);
}
void PaletteLook::drawComboBox(juce::Graphics& g, int width, int height, bool, int, int, int, int, juce::ComboBox&)
{
    g.setColour(juce::Colours::white);
    g.fillRoundedRectangle(0.5f, 0.5f, static_cast<float>(width - 1), static_cast<float>(height - 1), 8);
    g.setColour(ink.withAlpha(0.12f));
    g.drawRoundedRectangle(0.5f, 0.5f, static_cast<float>(width - 1), static_cast<float>(height - 1), 8, 1);
    juce::Path arrow;
    arrow.startNewSubPath(static_cast<float>(width - 19), static_cast<float>(height / 2 - 2));
    arrow.lineTo(static_cast<float>(width - 14), static_cast<float>(height / 2 + 3));
    arrow.lineTo(static_cast<float>(width - 9), static_cast<float>(height / 2 - 2));
    g.setColour(muted);
    g.strokePath(arrow, juce::PathStrokeType(1.5f));
}
void ChordPaletteEditor::connect(juce::ComboBox& box, const char* id, const juce::StringArray& items)
{
    box.addItemList(items, 1);
    addAndMakeVisible(box);
    attachments.push_back(std::make_unique<juce::AudioProcessorValueTreeState::ComboBoxAttachment>(processor.state, id, box));
}
ChordPaletteEditor::ChordPaletteEditor(ChordPaletteProcessor& p) : AudioProcessorEditor(p), processor(p)
{
    setLookAndFeel(&look);
    juce::StringArray rootNames, qualityNames, velocities;
    for (auto name : cp::roots) rootNames.add(name);
    for (auto name : cp::qualities) qualityNames.add(name);
    for (int i = 1; i <= 127; ++i) velocities.add(juce::String(i));
    connect(key, "key", rootNames);
    connect(scale, "scale", {"Major", "Natural minor"});
    connect(sevenths, "seventh", {"Triads", "Sevenths"});
    connect(root, "root", rootNames);
    connect(quality, "quality", qualityNames);
    connect(octave, "octave", {"2", "3", "4", "5", "6"});
    connect(inversion, "inversion", {"Root", "First", "Second", "Third"});
    connect(mode, "mode", {"Selected chord", "Transpose from C4"});
    connect(velocity, "velocity", velocities);
    connect(length, "length", {"1 beat", "2 beats", "4 beats", "8 beats"});
    connect(monitor, "monitor", {"Off", "On"});
#if ! CHORDPALETTE_AUDIO_PREVIEW
    monitor.setVisible(false);
#endif
    for (size_t i = 0; i < degrees.size(); ++i)
    {
        addAndMakeVisible(degrees[i]);
        degrees[i].onClick = [this, i]
        {
            const auto selected = cp::degree(static_cast<int>(processor.value("key")), processor.value("scale") > 0.5f,
                static_cast<int>(i), processor.value("seventh") > 0.5f, processor.settings());
            processor.setParameter("root", static_cast<float>(selected.root));
            processor.setParameter("quality", static_cast<float>(selected.quality));
            repaint();
        };
    }
    for (juce::Button* button : std::array<juce::Button*, 4>{&audition, &save, &panic, &drag}) addAndMakeVisible(button);
    audition.setColour(juce::TextButton::buttonColourId, accent);
    audition.onStateChange = [this] { processor.setPreview(audition.isDown()); };
    audition.setTooltip("Hold to send this chord to the instrument. Release to stop.");
    save.onClick = [this] { exportMidi(); };
    drag.setButtonText("Drag MIDI to DAW");
    drag.beginDrag = [this] { dragMidi(); };
    drag.setTooltip("Drag this button onto your DAW timeline. If the host does not accept it, use Save MIDI.");
    panic.onClick = [this] { processor.panic(); status = "All generated notes stopped"; repaint(); };
    mode.setTooltip("Selected: any incoming key plays this chord. Transpose: C4 plays it as shown; other keys shift every note.");
    inversion.setTooltip("Third inversion is used for chords with four or more notes; triads use second inversion.");
    setSize(900, 680);
    timerCallback();
    startTimerHz(20);
}
ChordPaletteEditor::~ChordPaletteEditor()
{
    stopTimer();
    processor.setPreview(false);
    chooser.reset();
    // The native drag may still be finishing after this editor closes. Leave its
    // temporary MIDI file available; the OS temporary directory owns cleanup.
    setLookAndFeel(nullptr);
}
void ChordPaletteEditor::timerCallback()
{
    const auto selected = processor.settings();
    const bool minor = processor.value("scale") > 0.5f;
    const char* majorDegrees[] = {"I", "ii", "iii", "IV", "V", "vi", "vii dim"};
    const char* minorDegrees[] = {"i", "ii dim", "III", "iv", "v", "VI", "VII"};
    for (size_t i = 0; i < degrees.size(); ++i)
    {
        const auto chord = cp::degree(static_cast<int>(processor.value("key")), minor, static_cast<int>(i),
            processor.value("seventh") > 0.5f, selected);
        degrees[i].setButtonText(juce::String(minor ? minorDegrees[i] : majorDegrees[i]) + "   " + cp::name(chord));
        degrees[i].setToggleState(chord.root == selected.root && chord.quality == selected.quality, juce::dontSendNotification);
    }
    if (! isShowing()) processor.setPreview(false);
    repaint();
}
void ChordPaletteEditor::resized()
{
    key.setBounds(32, 132, 100, 34);
    scale.setBounds(146, 132, 160, 34);
    sevenths.setBounds(320, 132, 150, 34);
    for (size_t i = 0; i < degrees.size(); ++i)
        degrees[i].setBounds(32 + static_cast<int>(i) * 121, 183, 111, 46);
    root.setBounds(430, 300, 80, 36);
    quality.setBounds(522, 300, 180, 36);
    octave.setBounds(714, 300, 62, 36);
    inversion.setBounds(788, 300, 80, 36);
    audition.setBounds(32, 430, 182, 40);
    panic.setBounds(230, 430, 152, 40);
    mode.setBounds(32, 526, 206, 36);
    velocity.setBounds(252, 526, 94, 36);
    length.setBounds(360, 526, 116, 36);
    monitor.setBounds(490, 526, 106, 36);
    drag.setBounds(620, 512, 248, 42);
    save.setBounds(620, 566, 248, 36);
}
void ChordPaletteEditor::keyboard(juce::Graphics& g, juce::Rectangle<float> area)
{
    const auto notes = cp::chord(processor.settings());
    auto lit = [&notes](int pitch)
    {
        for (int i = 0; i < notes.size; ++i) if (notes.pitches[static_cast<size_t>(i)] == pitch) return true;
        return false;
    };
    auto black = [](int pitch) { const int n = pitch % 12; return n == 1 || n == 3 || n == 6 || n == 8 || n == 10; };
    const float width = area.getWidth() / 35.0f;
    int white = 0;
    for (int pitch = 36; pitch < 96; ++pitch)
    {
        if (black(pitch)) continue;
        auto keyArea = juce::Rectangle<float>(area.getX() + static_cast<float>(white++) * width, area.getY(), width - 1, area.getHeight());
        g.setColour(lit(pitch) ? accent : juce::Colours::white);
        g.fillRoundedRectangle(keyArea, 3);
        g.setColour(ink.withAlpha(0.14f));
        g.drawRoundedRectangle(keyArea, 3, 1);
        if (pitch % 12 == 0)
        {
            g.setColour(muted);
            g.setFont(juce::FontOptions(10.0f));
            g.drawText("C" + juce::String(pitch / 12 - 1), keyArea.withTrimmedTop(area.getHeight() - 17), juce::Justification::centred);
        }
    }
    white = 0;
    for (int pitch = 36; pitch < 96; ++pitch)
    {
        if (! black(pitch)) { ++white; continue; }
        const auto keyArea = juce::Rectangle<float>(area.getX() + static_cast<float>(white) * width - width * 0.33f,
            area.getY(), width * 0.64f, area.getHeight() * 0.61f);
        g.setColour(lit(pitch) ? juce::Colour(0xff69b68b) : ink);
        g.fillRoundedRectangle(keyArea, 3);
    }
}
void ChordPaletteEditor::paint(juce::Graphics& g)
{
    g.fillAll(paper);
    g.setColour(ink);
    g.setFont(juce::FontOptions(30.0f, juce::Font::bold));
    g.drawText("ChordPalette", 32, 23, 420, 42, juce::Justification::centredLeft);
    label(g, "A little inspiration, one chord at a time", 34, 67, 470);
    label(g, CHORDPALETTE_AUDIO_PREVIEW ? "PLAYER  /  v0.1" : "LOGIC MIDI FX  /  v0.1", 694, 36, 174);
    g.setColour(ink.withAlpha(0.08f));
    g.drawHorizontalLine(100, 32, 868);
    label(g, "KEY", 32, 112, 100);
    label(g, "SCALE", 146, 112, 160);
    label(g, "PALETTE", 320, 112, 150);
    label(g, "Chords in your key", 620, 137, 248);
    g.setColour(juce::Colour(0xffe7eee4));
    g.fillRoundedRectangle(20, 250, 860, 236, 16);
    label(g, "SELECTED CHORD", 32, 265, 300);
    const auto selected = processor.settings();
    const auto notes = cp::chord(selected);
    g.setColour(ink);
    g.setFont(juce::FontOptions(40.0f, juce::Font::bold));
    g.drawText(cp::name(selected), 32, 286, 228, 52, juce::Justification::centredLeft);
    juce::StringArray noteNames;
    for (int i = 0; i < notes.size; ++i)
    {
        const int pitch = notes.pitches[static_cast<size_t>(i)];
        noteNames.add(juce::String(cp::roots[static_cast<size_t>(pitch % 12)]) + juce::String(pitch / 12 - 1));
    }
    label(g, noteNames.joinIntoString("  /  "), 240, 310, 180);
    label(g, "ROOT", 430, 280, 80);
    label(g, "CHORD TYPE", 522, 280, 180);
    label(g, "OCTAVE", 714, 280, 62);
    label(g, "INVERSION", 788, 280, 80);
    keyboard(g, {32, 352, 836, 62});
    label(g, "Live MIDI uses your keyboard velocity", 430, 442, 420);
    label(g, "LIVE TRIGGER", 32, 506, 206);
    label(g, "VELOCITY", 252, 506, 94);
    label(g, "MIDI LENGTH", 360, 506, 116);
#if CHORDPALETTE_AUDIO_PREVIEW
    label(g, "BUILT-IN SOUND", 490, 506, 116);
#endif
    label(g, processor.value("mode") < 0.5f ? "Any MIDI key plays the selected chord. Release it to stop."
        : "C4 plays the selected voicing. Other keys transpose it by semitones.", 32, 576, 560);
    g.setColour(ink.withAlpha(0.08f));
    g.drawHorizontalLine(630, 32, 868);
    label(g, status, 32, 643, 836);
}
void ChordPaletteEditor::exportMidi()
{
    chooser = std::make_unique<juce::FileChooser>("Save your chord as MIDI",
        juce::File::getSpecialLocation(juce::File::userDocumentsDirectory).getChildFile(cp::name(processor.settings()) + ".mid"), "*.mid");
    juce::Component::SafePointer<ChordPaletteEditor> safe(this);
    chooser->launchAsync(juce::FileBrowserComponent::saveMode | juce::FileBrowserComponent::canSelectFiles
        | juce::FileBrowserComponent::warnAboutOverwriting, [safe](const juce::FileChooser& result)
    {
        if (safe == nullptr) return;
        const auto target = result.getResult();
        if (target == juce::File()) return;
        safe->status = safe->processor.writeMidi(target.withFileExtension("mid")) ? "MIDI saved. Drop it onto your instrument track."
                                                                                  : "Could not save MIDI. Try another folder.";
        safe->repaint();
    });
}
void ChordPaletteEditor::dragMidi()
{
    const auto file = juce::File::getSpecialLocation(juce::File::tempDirectory)
        .getNonexistentChildFile("ChordPalette-" + cp::name(processor.settings()), ".mid");
    if (! processor.writeMidi(file)) { status = "Could not create MIDI. Try Save MIDI."; return; }
    if (! juce::DragAndDropContainer::performExternalDragDropOfFiles({file.getFullPathName()}, false, &drag))
        status = "Drag unavailable here. Use Save MIDI, then import the file.";
    else status = "Drop onto the timeline to create a MIDI region";
    repaint();
}
