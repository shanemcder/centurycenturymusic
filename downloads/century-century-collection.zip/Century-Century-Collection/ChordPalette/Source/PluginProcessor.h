#pragma once
#include <juce_audio_utils/juce_audio_utils.h>
#include "ChordEngine.h"

class ChordPaletteProcessor : public juce::AudioProcessor
{
public:
    ChordPaletteProcessor();
    ~ChordPaletteProcessor() override = default;
    using juce::AudioProcessor::processBlock;
    using juce::AudioProcessor::processBlockBypassed;
    using juce::AudioProcessor::setParameter;
    void prepareToPlay(double, int) override;
    void releaseResources() override;
    void reset() override { panic(); }
    void processBlock(juce::AudioBuffer<float>&, juce::MidiBuffer&) override;
    void processBlockBypassed(juce::AudioBuffer<float>&, juce::MidiBuffer&) override;
    bool isBusesLayoutSupported(const BusesLayout&) const override;
    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }
    const juce::String getName() const override { return JucePlugin_Name; }
    bool acceptsMidi() const override { return true; }
    bool producesMidi() const override { return true; }
    bool isMidiEffect() const override { return ! CHORDPALETTE_AUDIO_PREVIEW; }
    double getTailLengthSeconds() const override { return CHORDPALETTE_AUDIO_PREVIEW ? 0.25 : 0.0; }
    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram(int) override {}
    const juce::String getProgramName(int) override { return {}; }
    void changeProgramName(int, const juce::String&) override {}
    void getStateInformation(juce::MemoryBlock&) override;
    void setStateInformation(const void*, int) override;
    cp::Settings settings() const;
    float value(const juce::String&) const;
    void setParameter(const juce::String&, float);
    bool writeMidi(const juce::File&) const;
    void setPreview(bool down) { previewDown.store(down); }
    void panic() { previewDown.store(false); panicRequested.store(true); }
    juce::AudioProcessorValueTreeState state;
private:
    static juce::AudioProcessorValueTreeState::ParameterLayout layout();
    cp::LiveEngine live;
    juce::MidiBuffer output;
    juce::Synthesiser synth;
    std::atomic<bool> previewDown {false}, panicRequested {false};
    bool wasPlaying = false;
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(ChordPaletteProcessor)
};
