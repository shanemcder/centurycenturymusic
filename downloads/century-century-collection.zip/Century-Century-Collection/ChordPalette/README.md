# ChordPalette

A chord picker, MIDI generator, and live chord trigger built in C++ with JUCE 8.0.12.

## Build on your Mac

This download contains the source project, not a prebuilt `.component`. Build it locally to create the plugin for your Mac.

1. Unzip `ChordPalette_v0.1.zip` in Downloads.
2. If Apple's command line tools are not installed, run `xcode-select --install` in Terminal and finish their installer.
3. Install CMake if needed: `brew install cmake`. If you do not use Homebrew, install CMake from https://cmake.org/download/ and make its `cmake` command available in Terminal.
4. Run:

```bash
cd ~/Downloads/ChordPalette
bash scripts/build-mac.sh
bash scripts/install-mac.sh
```

The first build downloads JUCE, so an internet connection is required. This can take several minutes. The default build targets your Mac's current architecture. To build both Intel and Apple Silicon, configure with `cmake -S . -B build-universal -DCMAKE_BUILD_TYPE=Release '-DCMAKE_OSX_ARCHITECTURES=arm64;x86_64'`, then build that folder and copy its bundles manually.

If you already have a JUCE checkout, use `cmake -S . -B build -DJUCE_DIR=/absolute/path/to/JUCE -DCMAKE_BUILD_TYPE=Release`, then `cmake --build build --parallel 2`.

## Use in Logic Pro

1. Quit and reopen Logic after installing.
2. Create a software instrument track and load an instrument, such as Alchemy or a piano.
3. In the track's **MIDI FX** slot, choose **Century Century > ChordPalette**. The MIDI FX version sends notes to the instrument below it; it has no sound of its own.
4. Pick your key and major or natural minor scale. Click a palette chord, or choose a root and chord type manually.
5. Hold **Hold to audition** to hear the selected voicing through the instrument. Release to stop.
6. Play a MIDI key to trigger a chord. **Selected chord** maps every input note to the chord shown. **Transpose from C4** uses MIDI note 60 as the reference and shifts the complete voicing by the incoming note's semitone distance. Octave labels differ between DAWs: the plugin calls MIDI note 60 C4 even if Logic displays it as C3.
7. Drag **Drag MIDI to DAW** onto the instrument track's timeline to create a region, or use **Save MIDI...** and import the `.mid` file. Choose its length in beats first. Exported MIDI follows the project's tempo and includes no tempo change.

Host support for dragging differs; Save MIDI is the fallback. Record incoming keys for a repeatable live performance, or use exported MIDI to obtain editable generated chord notes in the arrangement. Depending on host routing, recording a track may capture the original trigger keys rather than the generated chord.

If Logic does not list it, open Logic's Plug-in Manager and rescan ChordPalette. Terminal validation command:

```bash
auval -v aumi Chpl Cnty
```

If this fails, keep the error output for troubleshooting. Do not delete your other plugins or reset all of Logic's preferences.

## Standalone and VST3 Player

The build also creates **ChordPalette Player**, a standalone app and a VST3 instrument. The Player contains a simple polyphonic audition sound. Find the app under `build/ChordPalettePlayer_artefacts/Release/Standalone/` (some generators omit `Release`). In its audio/MIDI settings, select an output device and enable your MIDI keyboard.

The VST3 Player can generate MIDI and audition it, but routing its MIDI output to another instrument depends on the host. Turn **Built-in sound** off if you want only generated MIDI. Logic uses the Audio Unit MIDI FX version, not this VST3. Ableton compatibility is not validated in this release; MIDI file export remains available regardless of live routing.

## Included features

- Major and natural minor chord palettes, with triads or seventh chords
- 14 chord types: major, minor, diminished, augmented, sus2, sus4, major seventh, minor seventh, dominant seventh, half-diminished seventh, diminished seventh, add9, major ninth, minor ninth
- Root, octave, and inversion controls, note names, and a voicing keyboard display
- Selected-chord and chromatic-transpose live modes
- MIDI velocity preserved from live input; separate audition/export velocity
- Sustain pedal, per-channel note ownership, overlap handling, and a Stop all notes button
- MIDI file saving and native MIDI file drag, with 1, 2, 4, or 8 beat lengths
- DAW state recall and exposed parameters for automation

The palette chooses chord root and type; it does not constrain manual chords or transpose mode to the selected scale. For triads, Third inversion resolves to Second. Notes outside MIDI range are omitted rather than clamped. Chords already held keep their original voicing until released; new triggers use the current settings. The keyboard display shows the selected voicing, not a live incoming-note monitor.

Note labels use a fixed set of enharmonic names, so a pitch may be displayed as Bb where your key would normally spell it A#. MIDI pitches are unchanged.

## Validation

See `VALIDATION.md` for checks performed on this release and remaining host checks. The macOS Audio Unit must still be compiled and tested in Logic on a Mac. This is an early development version, not a notarized installer.

Core tests require only a C++17 compiler and CMake:

```bash
cmake -S . -B build-tests -DCHORDPALETTE_CORE_ONLY=ON
cmake --build build-tests
ctest --test-dir build-tests --output-on-failure
```

## License

ChordPalette source is provided under the MIT license in `LICENSE`. JUCE is a separate dependency with its own license at https://github.com/juce-framework/JUCE/blob/8.0.12/LICENSE.md. Third-party SDK licenses also apply to their respective components. ChordPalette's MIT license does not relicense JUCE or its dependencies.
