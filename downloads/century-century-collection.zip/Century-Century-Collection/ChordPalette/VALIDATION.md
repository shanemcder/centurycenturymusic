# ChordPalette v0.1 validation

## Completed in the development workspace

- Built the VST3 instrument and standalone Player on Linux x86_64 with GCC 13 and JUCE 8.0.12 (JUCE commit `29396c22c93392d6738e021b83196283d6e4d850`). These Linux binaries are not included in the Mac source download.
- Compiled both MIDI-only and Player source configurations for C++ syntax checks.
- Passed the dependency-free chord and live engine test suite: explicit chord/inversion/scale cases, 10,080 voicing and transposition range combinations, reference-counted overlaps, channel isolation, retriggers, sustain, preview and panic.
- Passed 20,000 deterministic randomized live events with every generated note-on/note-off audited for balanced ownership; final panic leaves no active notes.
- Ran the core suite under AddressSanitizer and UndefinedBehaviorSanitizer. Leak detection was disabled because this environment does not support LeakSanitizer's process inspection.
- Passed the JUCE processor integration suite: sample offsets, output channels and velocity, matching original note-offs after changing a chord, audible Player output, silent monitoring with MIDI output, audition release, DAW state serialization/restore, bypass cleanup and transport-stop cleanup.
- Exported and decoded a MIDI file to verify a complete inverted Cmaj7 chord, velocity 88, 960 ticks per quarter note, four-beat duration, and absence of a tempo override.
- Rendered and visually inspected the actual JUCE editor. The included PNG is an editor render, not a mockup.
- Checked both Mac shell scripts for shell syntax.

## Checks still required on a Mac

- Build the AU MIDI processor and run `auval -v aumi Chpl Cnty` after installation.
- Load it in Logic's MIDI FX slot above an instrument and test audition, keyboard triggering, sustain, overlapping keys and Stop all notes.
- Try MIDI dragging into Logic; if the host rejects the drop, test Save MIDI and file import.
- Save/reopen a Logic session, automate chord parameters, and check bypass and playback stop behavior in the host.
- Test VST3 live MIDI routing in each intended host separately. No Ableton or other DAW compatibility claim is made by the Linux build checks.

The tests validate the source and engine behavior. They do not substitute for Audio Unit validation or testing inside Logic Pro.
